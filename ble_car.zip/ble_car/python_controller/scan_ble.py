#!/usr/bin/env python3
"""
List serial ports that may correspond to HC-05 Bluetooth SPP connections.

This avoids PyBluez (which can be troublesome on Python 3.13/Windows) and instead
shows the COM/RFCOMM ports available so you can pick the right one for HC-05.
"""

import sys

try:
    from serial.tools import list_ports
except ImportError:
    raise SystemExit("pyserial is required: pip install pyserial")


def main() -> None:
    ports = list_ports.comports()
    if not ports:
        print("No serial ports found.")
        return

    print("Available serial ports (look for HC-05/Bluetooth entries):")
    for p in ports:
        desc = p.description or ""
        manu = getattr(p, "manufacturer", "") or ""
        info_bits = [desc, manu]
        info = " - ".join(bit for bit in info_bits if bit)
        print(f"{p.device}: {info}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
