#!/usr/bin/env python3
"""
Send arrow-key commands to the Arduino car over an HC-05 Bluetooth SPP link.

Requires: pyserial (`pip install pyserial`)
Usage: python controller.py --port <COM_PORT>

Controls:
  Arrow keys = move (up/down/left/right)
  Space or s  = stop
  q or Ctrl+C = quit
"""

import argparse
import sys
from contextlib import contextmanager

import serial

ARROW_COMMANDS = {
    "\x1b[A": "F",  # Up arrow
    "\x1b[B": "B",  # Down arrow
    "\x1b[C": "R",  # Right arrow
    "\x1b[D": "L",  # Left arrow
}
LETTER_COMMANDS = {
    "w": "F",
    "W": "F",
    "s": "B",
    "S": "B",
    "a": "L",
    "A": "L",
    "d": "R",
    "D": "R",
    "f": "F",
    "F": "F",
    "b": "B",
    "B": "B",
    "l": "L",
    "L": "L",
    "r": "R",
    "R": "R",
}
STOP_KEYS = {" ", "x", "X"}
QUIT_KEYS = {"q", "Q"}


@contextmanager
def raw_terminal():
    if sys.platform == "win32":
        # Windows console does not need termios-style raw mode
        yield
        return

    import termios
    import tty

    fd = sys.stdin.fileno()
    original_attrs = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        yield
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, original_attrs)


def read_keypress() -> str:
    if sys.platform == "win32":
        import msvcrt

        first = msvcrt.getch()
        if first in (b"\x00", b"\xe0"):
            # Arrow/function keys send a prefix then a code
            code = msvcrt.getch()
            combo = first + code
            mapping = {
                b"\xe0H": "\x1b[A",  # Up
                b"\xe0P": "\x1b[B",  # Down
                b"\xe0M": "\x1b[C",  # Right
                b"\xe0K": "\x1b[D",  # Left
            }
            return mapping.get(combo, "")
        try:
            return first.decode("utf-8")
        except UnicodeDecodeError:
            return ""

    ch = sys.stdin.read(1)
    if ch == "\x1b":
        # Arrow keys arrive as ESC [ A|B|C|D
        ch += sys.stdin.read(2)
    return ch


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="HC-05 Bluetooth keyboard controller for the Arduino car")
    parser.add_argument("--port", required=True, help="Serial port exposed by HC-05 (e.g., COM5 or /dev/rfcomm0)")
    parser.add_argument("--baudrate", type=int, default=9600, help="HC-05 baud rate (default 9600)")
    parser.add_argument(
        "--no-raw",
        action="store_true",
        help="Disable raw key capture; type commands followed by Enter (useful for troubleshooting)",
    )
    return parser


def input_loop(ser: serial.Serial, use_raw: bool) -> None:
    print(
        "Connected. Use arrows or W/A/S/D/F/B/L/R to drive, space/X to stop, q to quit.",
        flush=True,
    )
    print("Press keys (or type then Enter if --no-raw).", flush=True)

    def process_key(key: str) -> bool:
        if key in QUIT_KEYS or key == "\x03":  # Ctrl+C
            print("Exiting...", flush=True)
            return False
        if key in STOP_KEYS:
            ser.write(b"S")
            ser.flush()
            print("Sent: Stop", flush=True)
            return True
        if key in ARROW_COMMANDS:
            cmd = ARROW_COMMANDS[key]
            ser.write(cmd.encode())
            ser.flush()
            print(f"Sent: {cmd}", flush=True)
            return True
        if key in LETTER_COMMANDS:
            cmd = LETTER_COMMANDS[key]
            ser.write(cmd.encode())
            ser.flush()
            print(f"Sent: {cmd}", flush=True)
            return True
        if key:
            print(f"Ignored key: {repr(key)}", flush=True)
        return True

    if use_raw:
        with raw_terminal():
            while True:
                if not process_key(read_keypress()):
                    break
    else:
        # Fallback: use line-based input for environments where raw key capture fails
        while True:
            try:
                line = input().strip()
            except EOFError:
                break
            for ch in line:
                if not process_key(ch):
                    return


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    try:
        print(f"Opening serial port {args.port} at {args.baudrate}...", flush=True)
        with serial.Serial(
            args.port,
            baudrate=args.baudrate,
            timeout=1,
            write_timeout=1,
        ) as ser:
            print("Port opened. Sending Stop (S)...", flush=True)
            ser.write(b"S")  # ensure stopped on connect
            ser.flush()
            input_loop(ser, use_raw=not args.no_raw)
    except serial.SerialException as exc:
        raise SystemExit(f"Failed to open serial port {args.port}: {exc}") from exc


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
