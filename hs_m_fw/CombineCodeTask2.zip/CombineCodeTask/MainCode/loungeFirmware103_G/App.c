
/******************************************************************************
 * @file    App.c
 * @author
 * @version
 * @date
 * @Recent Change:
 *     04-23-23    working backrest collision detection
 *     05-02-23    added a reverse feature to back up when a collision is detected
 *     05-08-23    added collision detection to the headrest
 *     05-09-23    updated so that both the headrest and backrest stop if a collision is detected on either. only the detected actuator moves backwards
 *     05-10-23    added slow stop to backrest min and max position. full retraction or extension resets the position.
 *     05-12-23    added slow stop to headrest min and max position. full retraction or extension resets the position.
 *     05-31-23    added code for software stop on BR extension
 *
 *     06-15-23    added code for software stop on HR extension
 *     08-30-23    added code to main.c to initialize LED. Added Code to blink the LED
 *     10-04-23    added code for motion of HR based on motion of BR also limits the HR motion at BR full extension- still bugs
 *     10-09-23    update code for motion auto motion only when inclining and is timed to start in later half of travel
 *     10-13-23    added code to allow for the software stop at the upright position depend on the backrest position.
 *     12-14-23    changed PWM timing from 666 (36kHz) to 333 (24kHz). this is in range of the motor driver spec
 *     12-15-23    fixed an issue with the MaxHRPosUpright calculation error. overflow in calculation due to too large of a multiplication. (old (((BR_Position*100)/(-553))+750);) (NEW (((BR_Position*10)/(-55))+750);)
 *
 *     12-21-23    adjusted indentation.
 *     12-26-23    added comments, cleaned up the code
 *     03-20-24    updated PWM timing from 333 to 1000 ( actual 24kHz). prior calculation was incorrect.
 *     04-30-24    Fixed issue where the HR would move in a stuttering motion when extending at the same time as the BR retracting. I prevented the actuator from stopping automatically while the BR is moving down.
 *     05-24-24    Attempting to fix issue where during the BR extension, holding the HR extend button the HR retracts due to auto motion but will not allow extension until you press retract once.
 *     05-29-24    Bug fixed in BR move up code. new behavior changes to HR auto motion and stops when BR reaches max.
 *     06-18-24    Increased the HR automatic travel speed when BR is moving to better match the timing of the BR. this is a new issue after fixing the previous bug on 5-24. the HR now stops when the BR stops.
 *
 *     06-28-24    Cleaned up code and comments
 *
 *     11-11-24    Cleaned up code, refractor of if conditions, WDT feature, initial 20s LED indication, remove unwanted functions and variables.
 *     05-09-25    BugFix- When pressing backrest forward button the headrest could not move backwards. If HR backwards button pressed, the HR position calibrated to zero
 *                 fized bug where quickly changing the direction of the hand switch at the max forward position would cause a calibration to happen.
 *****************************************************************************/

/* Standard Includes ---------------------------------------------------------*/
#include <msp430.h>

/* Project Includes ----------------------------------------------------------*/
#include "main.h"
#include "App.h"
#include "timer.h"
#include "ADC.h"

#define SLEEP_INACTIVITY_TICKS 10000u /* 1s at 0.1ms tick */

/* Set by App_TickTask when the system has been idle for the configured
 * interval. The main loop in main.c will observe and service this request. */
extern volatile unsigned char g_sleep_request;

#define ADC_STUCK_TIMEOUT_TICKS 50000UL // 5 seconds / 0.1ms tick
#define ADC_STUCK_NOISE_THRESHOLD 0     // Ignore +/-1 LSB of jitter // Changed to 0 from 1, to comply with actual testing, 3 Dec 2025

static inline unsigned int adc_abs_diff(unsigned int a, unsigned int b)
{
    return (a > b) ? (a - b) : (b - a);
}

/********************************************************************************************/

#pragma PERSISTENT(HR_Position) // keeps the position in the memory even after power off
volatile signed int HR_Position = 0;

#pragma PERSISTENT(BR_Position)
volatile signed int BR_Position = 0; // used to be -  volatile signed long int BR_Position = 200;

unsigned int MaxHRPosUpright = 300; // this is the max forward position of the headrest when the chair is fully upright
unsigned char HRAutoMoveFlag = 0;
// unsigned char logging = 'B';                   // for logging HR or BR enter H or B
/********************************************************************************************/

volatile unsigned long int BR_speed_counter = 0;
volatile unsigned long int HR_speed_counter = 0;

/*********************************************************************************/

extern unsigned int ADC_Result[16];

unsigned char HR_actuator_up = 0;
unsigned char HR_actuator_down = 0;
volatile unsigned char HR_duty_cycle_up_g = 0;
volatile unsigned char HR_duty_cycle_down_g = 0;
unsigned int HR_100ms_counter = 0;
unsigned int HR_speed_per_100ms = 0;

unsigned char BR_actuator_up = 0;
unsigned char BR_actuator_down = 0;
volatile unsigned char BR_duty_cycle_up_g = 0;
volatile unsigned char BR_duty_cycle_down_g = 0;
unsigned int BR_100ms_counter = 0;
unsigned int BR_speed_per_100ms = 0;

// unsigned char HR_wait_counter = 0;          //Not used in code
// unsigned char BR_wait_counter = 0;          //Not used in code

unsigned char HR_req_up_speed_status = 0;
unsigned char HR_req_down_speed_status = 0;

unsigned char BR_req_up_speed_status = 0;
unsigned char BR_req_down_speed_status = 0;

unsigned int PWM_timing_counter = 0;

unsigned int entry = 0;

unsigned char HR_stop_alert = 0;
unsigned char BR_stop_alert = 0;

volatile unsigned long adc_freeze_timer_ticks = 0;
volatile unsigned char adc_freeze_monitor_active = 0;
volatile unsigned char adc_freeze_trip = 0;

signed char BR_Obst_Flag = 0;          // flag that =1 when a current spike is detected
signed int BR_Recent_Avg_Current = 0;  // a variable used to hold the average of recent chunk of current readings
signed int BR_Recent_Sum_Current = 0;  // contains the sum of all the current readings so that it can be averaged
signed int BR_Prev_Avg_Current = 1000; // contains the previous value of Recent_Avg_Current this is a arbitrary high value to start so it doesn't measure a collision
// signed int TickTaskCount=0;                   //used for testing holds the count of how many loops of tick task has run
unsigned int BR_Current_Cycle_Count = 0; // used for determining when to start doing current averaging, after a set number of cycles

signed int BR_Return_Cycles_Count = 0; // this will count up the Return_Cycles
signed char BR_Return_Direction = 0;   // this is the direction the the motor needs to return to, -1 for retract and 1 for extend

signed char HR_Obst_Flag = 0;            // flag that =1 when a current spike is detected
signed int HR_Recent_Avg_Current = 0;    // a variable used to hold the average of recent chunk of current readings
signed int HR_Recent_Sum_Current = 0;    // contains the sum of all the current readings so that it can be averaged
signed int HR_Prev_Avg_Current = 1000;   // contains the previous value of Recent_Avg_Current
unsigned int HR_Current_Cycle_Count = 0; // used for determining when to start doing current averaging, after a set number of cycles

signed int HR_Return_Cycles_Count = 0; // this will count up the Return_Cycles
signed char HR_Return_Direction = 0;   // this is the direction the the motor needs to return to, -1 for retract and 1 for extend

signed int BR_Stop_Count = 0; // stop counts are used to count the number of cycles before considering an end stop. This avoids accidental reset of end position
signed int HR_Stop_Count = 0;

signed int LED_Timer = 0; // this is the counter for LED blink timing

void App_Task(void)
{
    static unsigned int prev_hr_up_adc = 0xFFFF;
    static unsigned int prev_hr_down_adc = 0xFFFF;
    static unsigned int prev_br_up_adc = 0xFFFF;
    static unsigned int prev_br_down_adc = 0xFFFF;
    unsigned char freeze_candidate = 0;

    if (prev_hr_up_adc != 0xFFFF)
    {
        unsigned char hr_up_same = adc_abs_diff(HR_UP_SW_ADC, prev_hr_up_adc) <= ADC_STUCK_NOISE_THRESHOLD;
        unsigned char hr_down_same = adc_abs_diff(HR_DOWN_SW_ADC, prev_hr_down_adc) <= ADC_STUCK_NOISE_THRESHOLD;
        unsigned char br_up_same = adc_abs_diff(BR_UP_SW_ADC, prev_br_up_adc) <= ADC_STUCK_NOISE_THRESHOLD;
        unsigned char br_down_same = adc_abs_diff(BR_DOWN_SW_ADC, prev_br_down_adc) <= ADC_STUCK_NOISE_THRESHOLD;

        if (hr_up_same && hr_down_same && br_up_same && br_down_same)
        {
            freeze_candidate = 1;
        }
    }

    if (freeze_candidate)
    {
        adc_freeze_monitor_active = 1;
    }
    else
    {
        adc_freeze_monitor_active = 0;
        adc_freeze_timer_ticks = 0;
    }

    prev_hr_up_adc = HR_UP_SW_ADC;
    prev_hr_down_adc = HR_DOWN_SW_ADC;
    prev_br_up_adc = BR_UP_SW_ADC;
    prev_br_down_adc = BR_DOWN_SW_ADC;

    // Check drive fault conditions
    if (!(P3IN & HR_DRV_FAULT))
    {
        HR_Fault_Reset();
    }
    if (P3IN & HR_DRV_FAULT)
    {
        P2OUT |= HR_DRV_SLEEP;
    }

    if (!(P3IN & BR_DRV_FAULT))
    {
        BR_Fault_Reset();
    }
    if (P3IN & BR_DRV_FAULT)
    {
        P2OUT |= BR_DRV_SLEEP;
    }

    // Check HR switch state
    if ((P3IN & HR_DRV_FAULT) && (P2OUT & HR_DRV_SLEEP) && (HR_stop_alert == 0))
    {
        if ((HR_DOWN_SW_ADC > 270) && (HR_DOWN_SW_ADC < 574))
        {
            HR_actuator_up = 1;
            TA1CCR1 = HR_DUTYCYCLE_UP;
            TA1CCR2 = HR_DUTYCYCLE_DOWN;
        }
        else
        {
            HR_actuator_up = 0;
            TA1CCR1 = HR_DUTYCYCLE_UP;
            TA1CCR2 = HR_DUTYCYCLE_DOWN;
        }
        if ((HR_UP_SW_ADC > 270) && (HR_UP_SW_ADC < 574))
        {
            HR_actuator_down = 1;
            TA1CCR1 = HR_DUTYCYCLE_UP;
            TA1CCR2 = HR_DUTYCYCLE_DOWN;
        }
        else
        {
            HR_actuator_down = 0;
            TA1CCR1 = HR_DUTYCYCLE_UP;
            TA1CCR2 = HR_DUTYCYCLE_DOWN;
        }
        if ((HR_UP_SW_ADC > 744) && (HR_DOWN_SW_ADC > 744))
        {
            HR_brake();
        }
    }

    // Check BR switch state
    if ((P3IN & BR_DRV_FAULT) && (P2OUT & BR_DRV_SLEEP) && (BR_stop_alert == 0))
    {
        if ((BR_UP_SW_ADC > 270) && (BR_UP_SW_ADC < 574))
        {
            BR_actuator_up = 1;
            TB0CCR1 = BR_DUTYCYCLE_UP;
            TB0CCR2 = BR_DUTYCYCLE_DOWN;
        }
        else
        {
            BR_actuator_up = 0;
            TB0CCR1 = BR_DUTYCYCLE_UP;
            TB0CCR2 = BR_DUTYCYCLE_DOWN;
        }

        if ((BR_DOWN_SW_ADC > 270) && (BR_DOWN_SW_ADC < 574))
        {
            BR_actuator_down = 1;
            TB0CCR1 = BR_DUTYCYCLE_UP;
            TB0CCR2 = BR_DUTYCYCLE_DOWN;
        }
        else
        {
            BR_actuator_down = 0;
            TB0CCR1 = BR_DUTYCYCLE_UP;
            TB0CCR2 = BR_DUTYCYCLE_DOWN;
        }

        if ((BR_UP_SW_ADC > 744) && (BR_DOWN_SW_ADC > 744))
        {
            BR_brake();
        }
    }

    // Conditions to apply HR and BR brake when respective duty cycles becomes zero.
    if (0 == (HR_duty_cycle_down_g + HR_duty_cycle_up_g))
    {
        if ((HR_UP_SW_ADC > 744 && HR_DOWN_SW_ADC > 744))
        {
            HR_brake();
        }
    }
    if (0 == (BR_duty_cycle_down_g + BR_duty_cycle_up_g))
    {
        if ((BR_UP_SW_ADC > 744) && (BR_DOWN_SW_ADC > 744))
        {
            BR_brake();
        }
    }

    // Clear the watchdog timer
    if (adc_freeze_trip)
    {
        while (1)
        {
            __no_operation();
        }
    }

    WDTCTL = WDTPW | WDTCNTCL;
}

void App_TickTask(void) // this loop runs every 0.1ms
{
    static unsigned char initial_20s_led_blink_flag = 1; // this flag is used to blink the LED for the first 20 seconds after power up
    static unsigned int LED_Blink_20s_Counter = 0;       // this counter is used to time first 20 seconds after power up
    static unsigned int timer_1s_Counter = 0;            // this counter is used to time 1s

    entry++;
    if (entry >= 2) // ADC is updated every 0.2ms
    {
        entry = 0;
        if ((ADC10CTL1 & ADC10BUSY) == 0x01)
        {
            // Do nothing when the ADC is busy
        }
        else
        {
            ADC_convert();
        }
    }

    //***************     This code blinks the LED for first 20s after power up
    if (1 == initial_20s_led_blink_flag)
    {
        timer_1s_Counter++;
        if (timer_1s_Counter >= 10000)
        { // Assuming App_TickTask runs every 0.1ms, 10000 * 0.1ms = 1s
            LED_Blink_20s_Counter++;
            timer_1s_Counter = 0;
            if (LED_Blink_20s_Counter >= 20)
            { // 20 * 1s = 20s
                initial_20s_led_blink_flag = 0;
                LED_Blink_20s_Counter = 0;
            }
        }

        LED_Timer++;
        if (LED_Timer < 1000)
        {
            P2OUT |= FAULT_LED; // sets LED HIGH
        }
        else if (LED_Timer < 12000)
        {
            P2OUT &= ~FAULT_LED;
        }
        else
        {
            LED_Timer = 0;
        }
    }
    //***************      This code blinks the LED for first 20s after power up

    if (adc_freeze_monitor_active)
    {
        if (adc_freeze_timer_ticks < ADC_STUCK_TIMEOUT_TICKS)
        {
            adc_freeze_timer_ticks++;
        }
        else
        {
            adc_freeze_trip = 1;
        }
    }
    else
    {
        adc_freeze_timer_ticks = 0;
    }

    /* --- Sleep mode inactivity monitor ------------------------------------
     * Count time with no user input and no motion. When it exceeds the
     * threshold, request sleep so the main loop can enter LPM3 cleanly. */
    {
        static unsigned int sleep_idle_ticks = 0;
        unsigned char any_pressed = 0;
        unsigned char any_moving = 0;

        /* A press is represented by the ADC value being in an expected window
         * (as already used in App_Task for control). */
        if ((HR_DOWN_SW_ADC > 270 && HR_DOWN_SW_ADC < 574) ||
            (HR_UP_SW_ADC   > 270 && HR_UP_SW_ADC   < 574) ||
            (BR_UP_SW_ADC   > 270 && BR_UP_SW_ADC   < 574) ||
            (BR_DOWN_SW_ADC > 270 && BR_DOWN_SW_ADC < 574))
        {
            any_pressed = 1;
        }

        if (((HR_duty_cycle_down_g + HR_duty_cycle_up_g) > 0) ||
            ((BR_duty_cycle_down_g + BR_duty_cycle_up_g) > 0))
        {
            any_moving = 1;
        }

        if (any_pressed || any_moving) {
            sleep_idle_ticks = 0;
        } else {
            if (sleep_idle_ticks < SLEEP_INACTIVITY_TICKS) {
                sleep_idle_ticks++;
            } else {
                /* Debounce: only set once until serviced */
                if (g_sleep_request == 0) {
                    g_sleep_request = 1;
                }
                sleep_idle_ticks = 0; /* reset so we don't spam */
            }
        }
    }

    //++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++START OF COLLISION DETECTION CODE+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    //    if (BR_Current_Cycle_Count>=BR_Min_Current_Cycle_Count + Cycles_Per_Current_Check){                    // count starts at 100, there are 100 cycles to allow for startup current
    //        BR_Recent_Avg_Current = BR_Recent_Sum_Current / (BR_Current_Cycle_Count - BR_Min_Current_Cycle_Count);
    //        if (BR_Recent_Avg_Current-BR_Prev_Avg_Current >BR_Max_Current_Spike){
    //            BR_Obst_Flag += 1;                                     // set the obstacle flag
    //
    //            if(BR_actuator_up == 1){
    //                BR_Return_Direction=-1;
    //            }
    //            else if(BR_actuator_down == 1){
    //                BR_Return_Direction=1;
    //            }
    //        }
    //        BR_Current_Cycle_Count = BR_Min_Current_Cycle_Count;            //used to reset the count back to the min count. this takes into account the skipped cycles for the startup
    //        BR_Prev_Avg_Current = BR_Recent_Avg_Current;                    //sets the previous current avg to the new one for the next calculation cycle
    //        BR_Recent_Sum_Current = 0;                                      //reset this back to zero to start a new cycle
    //    }
    //
    //    if (HR_Current_Cycle_Count>=HR_Min_Current_Cycle_Count + Cycles_Per_Current_Check){                    // count starts at 100, there are 100 cycles to allow for startup current
    //        HR_Recent_Avg_Current = HR_Recent_Sum_Current / (HR_Current_Cycle_Count - HR_Min_Current_Cycle_Count);
    //        if (HR_Recent_Avg_Current-HR_Prev_Avg_Current >HR_Max_Current_Spike){
    //            HR_Obst_Flag += 1;                                          // set the obstacle flag
    //
    //            if(HR_actuator_up == 1){
    //                HR_Return_Direction=-1;
    //            }
    //            else if(HR_actuator_down == 1){
    //                HR_Return_Direction=1;
    //            }
    //        }
    //
    //        HR_Current_Cycle_Count = HR_Min_Current_Cycle_Count;            //used to reset the count back to the min count. this takes into account the skipped cycles for the startup
    //        HR_Prev_Avg_Current = HR_Recent_Avg_Current;                    //sets the previous current avg to the new one for the next calculation cycle
    //        HR_Recent_Sum_Current = 0;                                      //reset this back to zero to start a new cycle
    //    }
    //
    //    if (BR_Obst_Flag >= 1 || HR_Obst_Flag >= 1){                        //sets the speed to zero when the obstacle has been detected
    //        collisionVarReset(1);
    //        collisionVarReset(0);
    //    }
    //
    //    if (BR_Obst_Flag >= 1 && BR_Return_Cycles_Count < Return_Cycles){
    //        if(BR_Return_Cycles_Count==0){                                  //do this on the fist loop
    //            BR_duty_cycle_up_g =0;                                      //first thing to do is stop completely
    //            BR_duty_cycle_down_g =0;
    //            HR_duty_cycle_up_g =0;                                      //first thing to do is stop completely
    //            HR_duty_cycle_down_g =0;
    //        }
    //        else if (BR_Return_Direction==-1){                              // the actuator will back off in the retract direction
    //            BR_duty_cycle_down_g =Return_Speed;                         //we set the speed to a specific value
    //        }
    //        else if (BR_Return_Direction==1){                               // the actuator will back off in the extend direction
    //            BR_duty_cycle_up_g =Return_Speed;
    //        }
    //        BR_Return_Cycles_Count++;
    //    }
    //    if (HR_Obst_Flag >= 1 && HR_Return_Cycles_Count < Return_Cycles){
    //        if(HR_Return_Cycles_Count==0){                                  //do this on the fist loop
    //            HR_duty_cycle_up_g =0;                                      //first thing to do is stop completely
    //            HR_duty_cycle_down_g =0;
    //            BR_duty_cycle_up_g =0;                                      //also stop to backrest
    //            BR_duty_cycle_down_g =0;
    //        }
    //        else if (HR_Return_Direction==-1){                              // the actuator will back off in the retract direction
    //            HR_duty_cycle_down_g =Return_Speed;                         //we set the speed to a specific value
    //        }
    //        else if (HR_Return_Direction==1){                               // the actuator will back off in the extend direction
    //            HR_duty_cycle_up_g =Return_Speed;
    //        }
    //        HR_Return_Cycles_Count++;
    //    }
    //
    //    if (BR_Return_Cycles_Count >= Return_Cycles){
    //        BR_duty_cycle_up_g =0;                                          //fully stops once fully backed off
    //        BR_duty_cycle_down_g =0;
    //        BR_Return_Direction=0;                                          //resets the return direction
    //    }
    //    if (HR_Return_Cycles_Count >= Return_Cycles){
    //        HR_duty_cycle_up_g =0;                                          //fully stops once fully backed off
    //        HR_duty_cycle_down_g =0;
    //        HR_Return_Direction=0;                                          //resets the return direction
    //    }
    //
    if ((BR_actuator_up == 0) && (BR_actuator_down == 0) && (BR_Return_Direction == 0))
    { // waits until both buttons are not pressed to reset the obstacle flag to 0
        BR_Obst_Flag = 0;
        collisionVarReset(1);
        BR_Return_Cycles_Count = 0;
        BR_Stop_Count = 0; // reset stop counts when buttons are not pressed
    }
    if ((HR_actuator_up == 0) && (HR_actuator_down == 0) && (HR_Return_Direction == 0))
    { // waits until both buttons are not pressed to reset the obstacle flag to 0
        HR_Obst_Flag = 0;
        collisionVarReset(0);
        HR_Return_Cycles_Count = 0;
        HR_Stop_Count = 0;
    }

    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ END OF COLLISION DETECTION CODE ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

    if ((HR_duty_cycle_down_g + HR_duty_cycle_up_g) > 0)
    {
        HR_100ms_counter++;
        if (HR_100ms_counter >= SPEED_MEASUREMENT * TIMING_FACTOR) // 0.1ms * 1000 = 100ms
        {
            HR_100ms_counter = 0;
            HR_speed_per_100ms = HR_speed_counter;
            HR_speed_counter = 0;
        }
    }

    if ((BR_duty_cycle_down_g + BR_duty_cycle_up_g) > 0)
    {
        BR_100ms_counter++;
        if (BR_100ms_counter >= SPEED_MEASUREMENT * TIMING_FACTOR)
        {
            BR_100ms_counter = 0;
            BR_speed_per_100ms = BR_speed_counter;
            BR_speed_counter = 0;
        }
    }

    PWM_timing_counter++;

    if (PWM_timing_counter > (6 * TIMING_FACTOR)) // 6ms
    {

        //@@@@@@@@@@@@@@   Code to determine the software limit of HR actuator based on BR position    @@@@@@@@@@@@@@@@@@@@@
        if (BR_Position > 1188)
        { // 1188 was taken as the lowest recline where the headrest is perpendicular to the ground at full extension.
            MaxHRPosUpright = (((BR_Position * 10) / (-55)) + 750);
            // this equation was created to keep the HR perpendicular to the ground as the maximum when upright
        }
        else
        {
            MaxHRPosUpright = HR_END_FINAL;
        }
        //@@@@@@@@@@@@@@   end of Code to determine the software limit of HR actuator based on BR position    @@@@@@@@@@@@@@

        if (BR_Obst_Flag == 0 && HR_Obst_Flag == 0)
        { // this checks if there is no obstacle detected

            //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$              Start of slow stop code                 $$$$$$$$$$$$$$$$$$$$$$$$$$$$$
            if (BR_Position <= BR_START_POS && BR_actuator_down == 1 && BR_actuator_up == 0)
            { // this checks if the BR is moving down and we are near the start so that we can start slowing down.
                if (BR_duty_cycle_down_g > BR_SLOW_DUTYCYCLE)
                {
                    BR_duty_cycle_down_g = BR_duty_cycle_down_g - 2;
                    collisionVarReset(1); // disables collision detection at the very end positions
                }
            }

            if (BR_Position >= BR_END_FINAL && BR_actuator_down == 0 && BR_actuator_up == 1)
            { // this checks if the BR is moving up and we are at the end so that we can stop.
                if (BR_duty_cycle_up_g > 0)
                {
                    BR_duty_cycle_up_g = 0;
                    collisionVarReset(1); // disables collision detection at the very end positions
                }
            }
            else if (BR_Position >= BR_END_POS && BR_actuator_down == 0 && BR_actuator_up == 1)
            { // this checks if the BR is moving up and we are near the end so that we can start slowing down.
                if (BR_duty_cycle_up_g > BR_SLOW_DUTYCYCLE)
                {
                    BR_duty_cycle_up_g = BR_duty_cycle_up_g - 2;
                    collisionVarReset(1); // disables collision detection at the very end positions
                }
            }

            if (HR_Position <= HR_START_POS && HR_actuator_down == 1 && HR_actuator_up == 0)
            { // this checks if the HR is moving down and we are near the start so that we can start slowing down.
                if (HR_duty_cycle_down_g > HR_SLOW_DUTYCYCLE)
                {
                    HR_duty_cycle_down_g = HR_duty_cycle_down_g - 2;
                    collisionVarReset(0); // disables collision detection at the very end positions
                }
            }
            if (HR_Position >= HR_END_FINAL && HR_actuator_down == 0 && HR_actuator_up == 1)
            {
                if (HR_duty_cycle_up_g > 0)
                {
                    HR_duty_cycle_up_g = 0;
                    collisionVarReset(0); // disables collision detection at the very end positions
                }
            }
            else if (HR_Position >= HR_END_POS && HR_actuator_down == 0 && HR_actuator_up == 1)
            {
                if (HR_duty_cycle_up_g > HR_SLOW_DUTYCYCLE)
                {
                    HR_duty_cycle_up_g = HR_duty_cycle_up_g - 2;
                    collisionVarReset(0); // disables collision detection at the very end positions
                }
            }
            //$$$$$$$$$$$$$$$$$$$$$$$$$$$$$              End of slow stop code                 $$$$$$$$$$$$$$$$$$$$$$$$$$$$$

            //%%%%%%%%%%%%%%% Start of code that resets the count to zero when the end position is reached  %%%%%%%%%%%%%%%%
            if (BR_ACTUATOR_CURRENT <= 2 && BR_actuator_down == 1 && BR_actuator_up == 0)
            { // if the current is near zero while the button is pressed then we can assume we are at start and set the pos to 0
                BR_Stop_Count++;
                if (BR_Stop_Count > 60)
                {
                    BR_Position = 0; // resets the position back to zero
                }
            }

            if (HR_ACTUATOR_CURRENT <= 2 && HR_actuator_down == 1 && HR_actuator_up == 0)
            { // if the current is near zero while the button is pressed then we can assume we are at start and set the pos to 0
                HR_Stop_Count++;
                if (HR_Stop_Count > 60)
                {
                    HR_Position = 0; // resets the position back to zero
                }
            }
            //%%%%%%%%%%%%%% end of code that resets the count to zero when the end position is reached  %%%%%%%%%%%%%%%%%%%
        }

        //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&   Start of code for HR and BR motion    &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&
        if ((1 == HR_actuator_up) && (0 == HR_Obst_Flag) && (0 == BR_Obst_Flag) && (HR_Position < MaxHRPosUpright))
        { // only runs when the button is pressed and there are no obstacle flags, position is less than the max upright position.
            if (0 == HR_duty_cycle_down_g)
            {

                if (HR_req_up_speed_status <= 10)
                { // will be used for collision detection so there is enough counts for detecting a collision current spike

                    if (HR_duty_cycle_up_g < HR_MIN_PWM_DUTYCYCLE)
                    {
                        HR_duty_cycle_up_g += 1;
                    }
                    else
                    {
                        HR_duty_cycle_up_g = HR_MIN_PWM_DUTYCYCLE;
                    }
                }
            }

            HR_Current_Cycle_Count++; // the count goes up when the button is pressed

            if (HR_Current_Cycle_Count > HR_Min_Current_Cycle_Count)
            { // this does not do anything for 100 counts to allow for startup. this gets reset when the button is released
                HR_Recent_Sum_Current += HR_ACTUATOR_CURRENT;
            }
        }

        if (((0 == HR_actuator_up) && (0 == HRAutoMoveFlag)) || ((HR_Position >= MaxHRPosUpright) && (BR_actuator_down != 1)))
        {
            HR_req_up_speed_status = 0;
            if (HR_duty_cycle_up_g > HR_SLOW_STOP_RATE) // brings the speed to 0
            {
                HR_duty_cycle_up_g -= HR_SLOW_STOP_RATE;
                collisionVarReset(0);
            }
            else
            {
                HR_duty_cycle_up_g = 0;
            }
        }

        if ((1 == HR_actuator_down) && (0 == HR_Obst_Flag) && (0 == BR_Obst_Flag))
        {
            if (0 == HR_duty_cycle_up_g)
            {
                if (HR_req_down_speed_status <= 10)
                {
                    if (HR_duty_cycle_down_g < HR_MIN_PWM_DUTYCYCLE)
                    {
                        HR_duty_cycle_down_g += 1;
                    }
                    else
                    {
                        HR_duty_cycle_down_g = HR_MIN_PWM_DUTYCYCLE;
                    }
                }
            }
            HR_Current_Cycle_Count++; // the count goes up when the button is pressed

            if (HR_Current_Cycle_Count > HR_Min_Current_Cycle_Count)
            { // this does not do anything for 100 counts to allow for startup. this gets reset when the button is released
                HR_Recent_Sum_Current += HR_ACTUATOR_CURRENT;
            }
        }

        if ((0 == HR_actuator_down) && (0 == HRAutoMoveFlag))
        {
            HR_req_down_speed_status = 0;
            if (HR_duty_cycle_down_g > HR_SLOW_STOP_RATE)
            {
                HR_duty_cycle_down_g -= HR_SLOW_STOP_RATE;
                collisionVarReset(0);
            }
            else
            {
                HR_duty_cycle_down_g = 0;
            }
        }

        if ((1 == BR_actuator_up) && (0 == BR_Obst_Flag) && (0 == HR_Obst_Flag)) // does not move if the flag has not been reset
        {
            if (0 == BR_duty_cycle_down_g)
            {
                if (BR_req_up_speed_status <= 10)
                {
                    if (BR_duty_cycle_up_g < BR_MIN_PWM_DUTYCYCLE)
                    {
                        BR_duty_cycle_up_g += 1;
                    }
                    else
                    {
                        BR_duty_cycle_up_g = BR_MIN_PWM_DUTYCYCLE;
                    }

                    if (BR_Position > 1188)
                    {
                        if ((HR_Position > 12) && (BR_Position < 2700))
                        { // this is where the HR stopping bug was found.
                            HRAutoMoveFlag = 1;
                            if (HR_duty_cycle_down_g < 55)
                            { // was 50 but at 55 it matches up on timing with BR
                                HR_duty_cycle_down_g += 1;
                            }
                        }
                        else
                        {
                            //                            if(HR_duty_cycle_down_g > 0){             //Bugfix 1.0.3
                            //                                HR_duty_cycle_down_g -= 1;            //Bugfix 1.0.3
                            //                            }
                            HRAutoMoveFlag = 0;
                        }
                    }
                }
            }
            BR_Current_Cycle_Count++; // the count goes up when the button is pressed

            if (BR_Current_Cycle_Count > BR_Min_Current_Cycle_Count)
            { // this does not do anything for 100 counts to allow for startup. this gets reset when the button is released
                BR_Recent_Sum_Current += BR_ACTUATOR_CURRENT;
            }
        }

        if (0 == BR_actuator_up)
        {
            if (!((HR_actuator_down == 1) && (HR_Obst_Flag == 0) && (BR_Obst_Flag == 0)))
            {
                if (HR_duty_cycle_down_g > 0)
                {
                    HR_duty_cycle_down_g -= 1;
                }
            }
            if (0 == BR_actuator_down)
            {
                HRAutoMoveFlag = 0;
            }

            BR_req_up_speed_status = 0;
            if (BR_duty_cycle_up_g > BR_SLOW_STOP_RATE)
            {
                BR_duty_cycle_up_g -= BR_SLOW_STOP_RATE;
                collisionVarReset(1);
                // reset the variables back to original values once the button is let go so fresh values can be used for the next time
            }
            else
            {
                BR_duty_cycle_up_g = 0;
            }
        }

        if ((1 == BR_actuator_down) && (0 == BR_Obst_Flag) && (0 == HR_Obst_Flag))
        {
            if (0 == BR_duty_cycle_up_g)
            {
                if (BR_req_down_speed_status <= 10)
                {
                    if (BR_duty_cycle_down_g < BR_MIN_PWM_DUTYCYCLE)
                    {
                        BR_duty_cycle_down_g += 1;
                    }
                    else
                    {
                        BR_duty_cycle_down_g = BR_MIN_PWM_DUTYCYCLE;
                    }
                }
            }
            BR_Current_Cycle_Count++;

            if (BR_Current_Cycle_Count > BR_Min_Current_Cycle_Count)
            {
                BR_Recent_Sum_Current += BR_ACTUATOR_CURRENT;
            }
        }

        if (0 == BR_actuator_down)
        {
            BR_req_down_speed_status = 0;
            if (BR_duty_cycle_down_g > BR_SLOW_STOP_RATE)
            {
                BR_duty_cycle_down_g -= BR_SLOW_STOP_RATE;
                collisionVarReset(1);
            }
            else
            {
                BR_duty_cycle_down_g = 0;
            }
        }

        //&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&   End of code for HR and BR motion    &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

        PWM_timing_counter = 0;
    }
}

void HR_Fault_Reset(void)
{
    P2OUT &= ~HR_DRV_SLEEP;
    __delay_cycles(20);
    if ((P3IN & HR_DRV_FAULT))
    {
        P2OUT |= HR_DRV_SLEEP;
        __delay_cycles(20000);
    }
}

void BR_Fault_Reset(void)
{
    P2OUT &= ~BR_DRV_SLEEP;
    __delay_cycles(20);
    if ((P3IN & BR_DRV_FAULT))
    {
        P2OUT |= BR_DRV_SLEEP;
        __delay_cycles(20000);
    }
}

void HR_brake(void)
{
    HR_actuator_up = 0;
    HR_actuator_down = 0;

    HR_speed_per_100ms = 0;
    HR_speed_counter = 0;

    // HR_wait_counter = 0;

    HR_req_up_speed_status = 0;
    HR_req_down_speed_status = 0;

    TA1CCR1 = HR_DUTYCYCLE_UP;
    TA1CCR2 = HR_DUTYCYCLE_DOWN;

    HR_stop_alert = 0;
}

void BR_brake(void)
{
    BR_actuator_up = 0;
    BR_actuator_down = 0;

    BR_speed_per_100ms = 0;
    BR_speed_counter = 0;

    // BR_wait_counter = 0;

    BR_req_up_speed_status = 0;
    BR_req_down_speed_status = 0;

    TB0CCR1 = BR_DUTYCYCLE_UP;
    TB0CCR2 = BR_DUTYCYCLE_DOWN;

    BR_stop_alert = 0;
}

void collisionVarReset(signed char val)
{ // val=1 for backrest  val = 0 for headrest
    if (val == 1)
    {
        BR_Current_Cycle_Count = 0;
        BR_Recent_Avg_Current = 0;
        BR_Recent_Sum_Current = 0;
        BR_Prev_Avg_Current = 1000;
    }

    if (val == 0)
    {
        HR_Current_Cycle_Count = 0;
        HR_Recent_Avg_Current = 0;
        HR_Recent_Sum_Current = 0;
        HR_Prev_Avg_Current = 1000;
    }
}

#pragma vector = PORT3_VECTOR
__interrupt void Port_3(void)
{
    if (P3IFG & BR_HALL_SENSOR_1)
    {
        BR_speed_counter++;
        if (BR_duty_cycle_up_g > 0)
        {
            BR_Position++;
        }
        else if (BR_duty_cycle_down_g > 0)
        {
            BR_Position--;
        }
        P3IES ^= BR_HALL_SENSOR_1;
        P3IFG &= ~BR_HALL_SENSOR_1; // Clear Interrupt Flag
    }

    if (P3IFG & BR_HALL_SENSOR_2)
    {
        BR_speed_counter++;
        if (BR_duty_cycle_up_g > 0)
        {
            BR_Position++;
        }
        else if (BR_duty_cycle_down_g > 0)
        {
            BR_Position--;
        }
        P3IES ^= BR_HALL_SENSOR_2;
        P3IFG &= ~BR_HALL_SENSOR_2; // Clear Interrupt Flag
    }

    if (P3IFG & HR_HALL_SENSOR_1)
    {
        HR_speed_counter++;
        if (HR_duty_cycle_up_g > 0)
        {
            HR_Position++;
        }
        else if (HR_duty_cycle_down_g > 0)
        {
            HR_Position--;
        }
        P3IES ^= HR_HALL_SENSOR_1;
        P3IFG &= ~HR_HALL_SENSOR_1; // Clear Interrupt Flag
    }

    if (P3IFG & HR_HALL_SENSOR_2)
    {
        HR_speed_counter++;
        if (HR_duty_cycle_up_g > 0)
        {
            HR_Position++;
        }
        else if (HR_duty_cycle_down_g > 0)
        {
            HR_Position--;
        }
        P3IES ^= HR_HALL_SENSOR_2;
        P3IFG &= ~HR_HALL_SENSOR_2; // Clear Interrupt Flag
    }
}
