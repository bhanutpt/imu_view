/******************************************************************************
  * @file    timer.c
  * @author
  * @version
  * @date
  * @brief   Source file for Monticello Application
  *****************************************************************************/

#include "timer.h"
#include <msp430.h>
#include "App.h"


void Timer_Initialize(void)
{
  TA0CCTL0 = CCIE;                          // TACCR0 interrupt enabled
  TA0CCR0 = 2400;                             // 0.1 milli second interrupt
  TA0CTL = TASSEL_1 + MC_1;                 // ACLK, UP mode

 __bis_SR_register(GIE);       // Enter LPM0 w/ interrupt
}


// Timer A0 interrupt service routine
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector = TIMER0_A0_VECTOR
__interrupt void Timer_A (void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(TIMER0_A0_VECTOR))) Timer_A (void)
#else
#error Compiler not supported!
#endif
{

    App_TickTask();

}
