
#ifndef APP_H_
#define APP_H_

// Macro Definitions
#define PWM_TIMEPERIOD  1000//333        //333=72kHz, 1000=24kHz,2000=12kHz, 8000=3kHz clockFrq/PWM_TIMEPERIOD = PWMFreq (ex. 24mHz/1000 = 24kHz)
#define HR_DUTYCYCLE_UP (PWM_TIMEPERIOD/100)*HR_duty_cycle_up_g
#define HR_DUTYCYCLE_DOWN (PWM_TIMEPERIOD/100)*HR_duty_cycle_down_g

#define BR_DUTYCYCLE_UP (PWM_TIMEPERIOD/100)*BR_duty_cycle_up_g
#define BR_DUTYCYCLE_DOWN (PWM_TIMEPERIOD/100)*BR_duty_cycle_down_g


#define HR_START_POS 70                         //this is the position where the slow stop starts
#define HR_END_POS   470                        //this is the position where the slow stop starts
#define HR_END_FINAL   540                      // this is the absolute final position. this can be used to adjust software stopping

#define HR_MIN_PWM_DUTYCYCLE   90               // PWM at no load to reach required speed
#define HR_SLOW_DUTYCYCLE   45

#define HR_SLOW_STOP_RATE   2
#define BR_SLOW_STOP_RATE   2

#define BR_START_POS 200                        //this is the position where the slow stop starts
#define BR_END_POS   2600                       //2300  this is the position where the slow stop starts
#define BR_END_FINAL   2750                     //2300   ~2750 end stop  // this is the absolute final position. this can be used to adjust software stopping

#define BR_MIN_PWM_DUTYCYCLE   100               // PWM at no load to reach required speed
#define BR_SLOW_DUTYCYCLE   40

#define SPEED_MEASUREMENT       100             // Speed is measured as counts per 100 milliseconds. this is a constant and used for calulation

#define TIMING_FACTOR   10

#define BR_ACTUATOR_CURRENT     ADC_Result[0]
#define HR_ACTUATOR_CURRENT     ADC_Result[1]

#define BR_UP_SW_ADC            ADC_Result[6]
#define BR_DOWN_SW_ADC          ADC_Result[7]

#define HR_UP_SW_ADC            ADC_Result[12]
#define HR_DOWN_SW_ADC          ADC_Result[13]

#define Cycles_Per_Current_Check 20             // this is the number of cycles before averaging the current and checking if there is a current spike
#define Return_Cycles 15000                     //number of cycles to back off when a collision is detected
#define Return_Speed 50                         //the PWM speed for backing off after a collision

#define  BR_Min_Current_Cycle_Count  100        //this is the number of cycles after a button is pressed before starting current detection
#define  BR_Max_Current_Spike 14                //11 worked well       //maximum allowed current spike between the previous current average and the new current average

#define  HR_Min_Current_Cycle_Count  100        //this is the number of cycles after a button is pressed before starting current detection
#define  HR_Max_Current_Spike 10                 //8 worked well  //maximum allowed current spike between the previous current average and the new current average

// Function Prototypes
void App_Task(void);
void App_TickTask (void);
void timer_variables_reset (void);
void HR_brake (void);
void BR_brake (void);
void HR_Fault_Reset (void);
void BR_Fault_Reset (void);
void collisionVarReset(signed char val);

#endif /* APP_H_ */
