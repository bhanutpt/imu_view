
#ifndef ADC_H_
#define ADC_H_


#define CURRENT     BIT0

void ADC_init (void);
void ADC_convert (void);
void HR_Current_Averaging (void);
void HR_Fetch_Current_Values (void);
void BR_Current_Averaging (void);
void BR_Fetch_Current_Values (void);

/* Utility used only during low-power sleep to detect a button press by
 * sampling the 4 analog switch channels once each and checking for a
 * mid-window voltage that represents a pressed state. Safe to call while
 * the system is in sleep mode; the main ADC DMA sequence will be
 * re-initialized upon wake. Returns 1 if any switch appears pressed. */
unsigned char ADC_scan_for_press(void);

void Current_Avg(void);

#endif /* ADC_H_ */
