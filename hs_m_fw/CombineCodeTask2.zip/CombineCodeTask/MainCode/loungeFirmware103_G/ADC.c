/******************************************************************************
  * @file    ADC.c
  * @author
  * @version
  * @date
  * @brief
  *****************************************************************************/

#include <msp430.h>
#include <stdint.h>
#include "ADC.h"
#include "main.h"

volatile unsigned int ADC_Result[16];                // 10-bit ADC conversion result array

volatile unsigned char HR_current_ADC_ready = 0;
volatile unsigned char BR_current_ADC_ready = 0;

void ADC_init(void)
{
    // Configure ADC
    P1SEL1 |= BR_CURRENT;               /* P1.0, A0 */
    P1SEL0 |= BR_CURRENT;

    P1SEL1 |= HR_CURRENT;               /* P1.1, A1 */
    P1SEL0 |= HR_CURRENT;

    P2SEL1 |= BR_FORWARD_SW;            /* P2.3, A6 */
    P2SEL0 |= BR_FORWARD_SW;

    P2SEL1 |= BR_REVERSE_SW;            /* P2.4, A7 */
    P2SEL0 |= BR_REVERSE_SW;

    P3SEL1 |= HR_REVERSE_SW;            /* P3.0, A12 */
    P3SEL0 |= HR_REVERSE_SW;

    P3SEL1 |= HR_FORWARD_SW;            /* P3.0, A13 */
    P3SEL0 |= HR_FORWARD_SW;

//    ADC10CTL0 |= ADC10SHT_2 + ADC10ON;        // ADC10ON, S&H=16 ADC clks
//    ADC10CTL1 |= ADC10SHP;                    // ADCCLK = MODOSC; sampling timer
//    ADC10CTL2 |= ADC10RES;                    // 10-bit conversion results
//
//    /*******************Analog PIN **********************/
//    ADC10MCTL0 |= ADC10INCH_12;                // A1 ADC input select; Vref=AVCC
//
//    ADC10IE |= ADC10IE0;                      // Enable ADC conv complete interrupt
//    __delay_cycles(100);                        // Wait for ADC ref to settle

//    ADC10CTL0 = ADC10SHT_4 + ADC10ON + ADC10MSC;    // S&H - 64 cycles; ADC ON; Multiple Conversions
//    ADC10CTL1 = ADC10SHP + ADC10CONSEQ_1;           // Sample-Hold Pulse selection; Sequence of Channels
//    ADC10CTL2 = ADC10RES;                           // 10-Bit Resolution
//    ADC10IE = ADC10IE0;                             // Enable Conversion Complete Interrupt
//
//    ADC10MCTL0 = ADC10INCH_15;        // We need A0, A1(Port 1), A6, A7(Port 2), A12, A13(Port 3)

    // Configure ADC10
      ADC10CTL0 = ADC10SHT_4 + ADC10MSC + ADC10ON;// 16ADCclks, MSC, ADC ON
      ADC10CTL1 = ADC10SHP + ADC10CONSEQ_1;     // sampling timer, s/w trig.,single sequence
      ADC10CTL2 = ADC10RES;                   // 8-bit resolution
      ADC10MCTL0 = ADC10INCH_15;                 // A0,A1,A2(EoS), AVCC reference

      // Configure DMA0 (ADC10IFG trigger)
      DMACTL0 = DMA0TSEL__ADC10IFG;             // ADC10IFG trigger
      __data20_write_long((uintptr_t) &DMA0SA,(uintptr_t) &ADC10MEM0);
                                                // Source single address
      __data20_write_long((uintptr_t) &DMA0DA,(uintptr_t) &ADC_Result[15]);
                                                // Destination array address
      DMA0SZ = 0x10;                            // 16 conversions
      //DMA0CTL = DMADT_4 + DMADSTINCR_2 + DMASRCBYTE + DMADSTBYTE + DMAEN + DMAIE;
      DMA0CTL = DMADT_4 + DMADSTINCR_2 + DMAEN + DMAIE;
                                                // Rpt Single Transfer, decrement dest, Source unchanged, byte access,
                                                // enable int after seq of convs


    __delay_cycles(1000);                        // Wait for ADC ref to settle
}

void ADC_convert (void)
{
    ADC10CTL0 |= ADC10ENC + ADC10SC;         // Sampling and conversion start
}

#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=DMA_VECTOR
__interrupt void DMA0_ISR (void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(DMA_VECTOR))) DMA0_ISR (void)
#else
#error Compiler not supported!
#endif
{
  switch(__even_in_range(DMAIV,16))
  {
    case  0: break;                          // No interrupt
    case  2:
      // sequence of conversions complete
        BR_current_ADC_ready = 1;
        HR_current_ADC_ready = 1;
      break;                                 // DMA0IFG
    case  4: break;                          // DMA1IFG
    case  6: break;                          // DMA2IFG
    case  8: break;                          // Reserved
    case 10: break;                          // Reserved
    case 12: break;                          // Reserved
    case 14: break;                          // Reserved
    case 16: break;                          // Reserved
    default: break;
  }
}

/* --- Low-power sleep helpers -------------------------------------------------
 * During sleep, we temporarily repurpose ADC10 for single-channel, on-demand
 * sampling to detect whether any of the four analog switches are pressed.
 * This function reconfigures the ADC for single conversions, samples each
 * switch channel once, checks for a mid-window level indicative of a press,
 * and returns 1 if any channel is pressed. It is intended to be called only
 * from the WDT ISR while in sleep mode. Upon wake, the main application
 * should call ADC_init() again to restore the DMA-based scan configuration.
 */

#define SWITCH_WINDOW_MID       (512u)
#define SWITCH_WINDOW_TOLERANCE (120u)
#define SWITCH_WINDOW_MIN       (SWITCH_WINDOW_MID - SWITCH_WINDOW_TOLERANCE)
#define SWITCH_WINDOW_MAX       (SWITCH_WINDOW_MID + SWITCH_WINDOW_TOLERANCE)

static unsigned int adc_sample_single_channel(unsigned int channel)
{
  /* Put ADC in single-channel, software trigger mode */
  ADC10CTL0 &= ~ADC10ENC;
  ADC10CTL0 = ADC10SHT_4 | ADC10ON;   /* 64 ADCCLK sample, ADC on       */
  ADC10CTL1 = ADC10SHP;                /* Use sampling timer, s/w trig   */
  ADC10CTL2 = ADC10RES;                /* 10-bit conversions             */

  /* Select channel and take one sample */
  ADC10MCTL0 = (channel | ADC10SREF_0);
  ADC10CTL0 |= (ADC10ENC | ADC10SC);
  while (ADC10CTL1 & ADC10BUSY)
    ;
  return ADC10MEM0;
}

static uint8_t adc_value_in_press_window(unsigned int value)
{
  return (value >= SWITCH_WINDOW_MIN) && (value <= SWITCH_WINDOW_MAX);
}

unsigned char ADC_scan_for_press(void)
{
  /* Switch analog channels as mapped in main.h comments:
   *  BR_FORWARD_SW -> A6, BR_REVERSE_SW -> A7,
   *  HR_REVERSE_SW -> A12, HR_FORWARD_SW -> A13
   */
  const unsigned int channels[4] = { ADC10INCH_6, ADC10INCH_7, ADC10INCH_12, ADC10INCH_13 };
  unsigned char pressed = 0;

  /* Ensure analog pin function is preserved (ADC_init already configured
   * P1/P2/P3 SEL registers). We only touch ADC10 control registers here. */
  for (unsigned int i = 0; i < 4; i++) {
    unsigned int sample = adc_sample_single_channel(channels[i]);
    if (adc_value_in_press_window(sample)) {
      pressed = 1;
    }
  }

  return pressed;
}

//// ADC10 interrupt service routine
//#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
//#pragma vector=ADC10_VECTOR
//__interrupt void ADC10_ISR(void)
//#elif defined(__GNUC__)
//void __attribute__ ((interrupt(ADC10_VECTOR))) ADC10_ISR (void)
//#else
//#error Compiler not supported!
//#endif
//{
//
//  switch(__even_in_range(ADC10IV,12))
//  {
//    case  0: break;                          // No interrupt
//    case  2: break;                          // conversion result overflow
//    case  4: break;                          // conversion time overflow
//    case  6: break;                          // ADC10HI
//    case  8: break;                          // ADC10LO
//    case 10: break;                          // ADC10IN
//    case 12:
//        ADC_Result[count] = ADC10MEM0;
//        if (count == 0)
//        {
//            BR_current_ADC_ready = 1;
//            count = 15;
//        }
//        else if (count == 1)
//        {
//            count--;
//            HR_current_ADC_ready = 1;
//        }
//        else
//            count--;
//        break;                          // Clear CPUOFF bit from 0(SR)
//    default: break;
//  }
//}
