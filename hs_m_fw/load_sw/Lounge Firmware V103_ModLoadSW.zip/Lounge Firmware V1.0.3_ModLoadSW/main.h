
/* Define to prevent recursive inclusion -------------------------------------*/

#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

#include  "stdbool.h"

/* Exported constants --------------------------------------------------------*/

#define CLOCK_FREQUENCY 16       //in MHz

/* ---------PORT 1 PIN Mapping -------------------*/

#define BR_CURRENT      BIT0    /*BR Actuator Current Monitoring -ADC Input A0*/
#define HR_CURRENT      BIT1    /*HR Actuator Current Monitoring -ADC Input A1*/

#define HR_FORWARD_ACT  BIT2    /*HR Actuator Forward Actuation - PWM Output */
#define HR_REVERSE_ACT  BIT3    /*HR Actuator Reverse Actuation - PWM Output */

#define BR_FORWARD_ACT  BIT4    /*BR Actuator Forward Actuation - PWM Output */
#define BR_REVERSE_ACT  BIT5    /*BR Actuator Reverse Actuation - PWM Output */

#define I2C_SDA     BIT6
#define I2C_SCL     BIT7

/* ---------PORT 2 PIN Mapping -------------------*/

#define SERIAL_TXD      BIT0    /* Serial Interface - Output TXD */
#define SERIAL_RXD      BIT1    /* Serial Interface - Input RXD */

//#define TESTING         BIT2    /* Unused Pin - Used for testing */

#define BR_FORWARD_SW   BIT3    /* BR Actuator Forward Switch - ADC input A6 */
#define BR_REVERSE_SW   BIT4    /* BR Actuator Reverse Switch - ADC input A7 */

#define HR_DRV_SLEEP    BIT5    /* Sleep pin for HR Driver - Output */
#define BR_DRV_SLEEP    BIT6    /* Sleep pin for BR Driver - Output */

#define FAULT_LED       BIT7    /* LED to indicate Fault - Output */

#define HALL_LOAD_SW       BIT2    /* LOAD SWITCH TO HALL SENSORS TO REDUCE POWER*/

/* ---------PORT 3 PIN Mapping -------------------*/

#define HR_REVERSE_SW   BIT0    /* HR Actuator Forward Switch - ADC input A12 */
#define HR_FORWARD_SW   BIT1    /* HR Actuator Reverse Switch - ADC input A13 */

#define HR_DRV_FAULT    BIT2    /* HR Driver Fault pin - Input */
#define BR_DRV_FAULT    BIT3    /* BR Driver Fault pin - Input */

#define HR_HALL_SENSOR_2       BIT4    /* HR Hall Sensor 2 input - Interrupt Input*/
#define HR_HALL_SENSOR_1       BIT5    /* HR Hall Sensor 1 input - Interrupt Input*/
//#define HR_HALL_SENSOR_1       BIT6    /* HR Hall Sensor 1 input - Interrupt Input*/
#define BR_HALL_SENSOR_2       BIT6    /* BR Hall Sensor 2 input - Interrupt Input*/
#define BR_HALL_SENSOR_1       BIT7    /* BR Hall Sensor 1 input - Interrupt Input*/



#endif /* MAIN_H_ */

 /******************* (C) COPYRIGHT 2023 HumanScale*****************************/
 /******************************END OF FILE*************************************/

