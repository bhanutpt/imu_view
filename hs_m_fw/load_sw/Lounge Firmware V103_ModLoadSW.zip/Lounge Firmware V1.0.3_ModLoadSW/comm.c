/*
 * comm.c
 *
 *  Created on: 10-Feb-2025
 *      Author: bb
 */

#include <msp430.h>
#include <string.h>
#include <stdio.h>


extern unsigned char fwVersion[3]; // = { MAJOR, MINOR, PATCH };  // major=1, minor=0, patch=0


void UART_Initialize(void)
{
    // 1. Enable special function on P2.0 and P2.1 for UCA0TXD and UCA0RXD:
//    P2SEL0 &= ~BIT0;
//    P2SEL1 |=  BIT1;

    P2SEL0 &= ~(BIT0 | BIT1);
    P2SEL1 |=  (BIT0 | BIT1);

    // 2. Put eUSCI_A in reset
    UCA0CTLW0 = UCSWRST;

    // 3. Choose SMCLK as clock, 8-bit data, no parity, LSB first, etc.
    //    (UCSSEL__SMCLK sets the clock source; everything else default)
    UCA0CTLW0 |= UCSSEL__SMCLK;

    /*
     * 4. Set your desired baud rate.
     *    For example, if your SMCLK = 24 MHz, and you want 9600 baud:
     *
     *    Baudrate = f_BAUD = f_SMCLK / (16 * UCBRx + UCBRFx + (UCBRSx / 8))
     *
     *    A common setting for 9600 at high frequencies:
     *       - UCBRx = 156
     *       - UCOS16 = 1  (enable oversampling)
     *       - UCBRF = 4 or 1, etc. depends on fine-tuning
     *       - UCBRS = 0, or some fraction
     */
    UCA0BRW = 156;       // integer part
    UCA0MCTLW = (4 << 8) // BRS = 4
               | UCOS16; // enable oversampling
    /*
     * Adjust BRS/BRF as needed. Another approach for 24 MHz / 9600 is:
     *   - BRW = 156
     *   - BRS = 1..6 (fine tune)
     *   - UCOS16 = 1
     * Or for 115,200, you might do something like:
     *   - BRW = 13
     *   - BRS = 0
     *   - UCOS16 = 1
     */

    // 5. Release from reset
    UCA0CTLW0 &= ~UCSWRST;

    // 6. Enable receive interrupts
    UCA0IE |= UCRXIE;
}


//#pragma vector = USCI_A0_VECTOR
//__interrupt void USCI_A0_ISR(void)
//{
//    switch(__even_in_range(UCA0IV, USCI_UART_UCTXCPTIFG))
//    {
//        case USCI_NONE:
//            break;
//
//        case USCI_UART_UCRXIFG:
//        {
//            // A character arrived in UCA0RXBUF
//            unsigned char received_char = UCA0RXBUF;
//
//            // TODO: do something with received_char
//            // e.g., store it in a buffer, parse a command, or echo it back
//            //
//            // For a quick test, you could just echo it back:
//            while (!(UCA0IFG & UCTXIFG)); // Wait for TX buffer ready
//            UCA0TXBUF = received_char;    // Echo back
//
//            break;
//        }
//
//        case USCI_UART_UCTXIFG:
//            // TX buffer empty (only needed if you are doing TX interrupts)
//            break;
//
//        case USCI_UART_UCTXCPTIFG:
//            // Transmission complete (not usually needed in basic apps)
//            break;
//
//        default:
//            break;
//    }
//}


// A simple helper to send a zero-terminated string via UART (polling).
void UART_Transmit_String(const char *str)
{
    while (*str)
    {
        while (!(UCA0IFG & UCTXIFG));  // Wait for TX buffer to be ready
        UCA0TXBUF = *str++;
    }
}


#pragma vector = USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)
{
    static char rxBuffer[16];        // Holds incoming characters
    static unsigned int rxIndex = 0; // Next position to store a char

    switch (__even_in_range(UCA0IV, USCI_UART_UCTXCPTIFG))
    {
    case USCI_UART_UCRXIFG:
    {
        // Read the newly-received character
        unsigned char c = UCA0RXBUF;

        // Store the character if there's room (leave space for terminator)
        if (rxIndex < (sizeof(rxBuffer) - 1))
        {
            rxBuffer[rxIndex++] = c;
        }

        // Check if we got an "end of line" (Enter key)
        if (c == '\r' || c == '\n')
        {
            // Replace the newline with string terminator
            rxBuffer[rxIndex - 1] = '\0';

            // Compare the received string with "fw?"
            if (strcmp(rxBuffer, "fw?") == 0)
            {
                // Build a string like: "ACFW v2.0.0_L\r\n"
                // (Increase versionStr[] if you want more buffer space)
                char versionStr[32];

                sprintf(versionStr,
                        "ACFW v%c.%c.%c_G\r\n",
                        fwVersion[0],   // major
                        fwVersion[1],   // minor
                        fwVersion[2]);  // patch

                // Transmit the version string back
                UART_Transmit_String(versionStr);
            }

            // Reset buffer index for the next command
            rxIndex = 0;
        }

        break;
    }

    case USCI_UART_UCTXIFG:
        // TX buffer empty interrupt (not used here)
        break;

    case USCI_UART_UCTXCPTIFG:
        // TX complete (optional, not used here)
        break;

    default:
        break;
    }
}


//void UART_Transmit_String(const char *str) {
//    while (*str) {
//        while (!(UCA0IFG & UCTXIFG)); // Wait for TX buffer to be ready
//        UCA0TXBUF = *str++;           // Send the next character
//    }
//}

void UART_Transmit(unsigned char data) {
    while (!(UCA0IFG & UCTXIFG)); // Wait for TX buffer to be ready
    UCA0TXBUF = data;             // Send the data
}

void UART_Test(void) {
    const char test_message[] = "UART Test: MSP430FR5735\r\n";
    UART_Transmit_String(test_message);

//    // Wait for a character and echo it back
//    while (!(UCA0IFG & UCRXIFG)); // Wait for RX buffer to be ready
//    unsigned char received_char = UCA0RXBUF;
//    UART_Transmit_String("Received: ");
////    UART_Transmit(received_char);
//    UART_Transmit_String("\r\n");
}
