
#ifndef TIMER_H_
#define TIMER_H_


void Timer_Initialize(void);

#endif /* TIMER_H_ */
