/*
 * comm.h
 *
 *  Created on: 10-Feb-2025
 *      Author: bb
 */

#ifndef COMM_H_
#define COMM_H_

void UART_Initialize(void);
void UART_Transmit(unsigned char data);
void UART_Receive_Handler(void);
void UART_Transmit_String(const char *str);
void UART_Test(void);

#endif /* COMM_H_ */
