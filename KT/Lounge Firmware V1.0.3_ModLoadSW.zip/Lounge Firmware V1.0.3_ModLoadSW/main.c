/******************************************************************************
  * @file    main.c
  * @author
  * @version
  * @date
  * @brief   Source file for Main Application
  *****************************************************************************/

/* Standard Includes ---------------------------------------------------------*/

#include <msp430.h>
#include <string.h>
#include <stdio.h>


/* Project Includes ----------------------------------------------------------*/

#include "main.h"
#include "App.h"
#include "timer.h"
#include "ADC.h"
#include "comm.h"

void WatchDog_Init(void);
void Board_Initialize (void);
void Clock_Initialize (void);
void PWM_Initialize (void);
void Speed_Sensor_Initialize (void);

// Firmware Version (Ascii)
#define MAJOR   49
#define MINOR   48
#define PATCH   51

#pragma PERSISTENT (fwVersion)
unsigned char fwVersion[3] = { MAJOR, MINOR, PATCH };  // major=1, minor=0, patch=0


int main(void)
{

    WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT

    Board_Initialize();
    Clock_Initialize();
    PWM_Initialize();
    UART_Initialize();

    __bic_SR_register(GIE);

    // Faster blink at power up to indicate a MCU rest,
    // and differentiate normal blinking at 0.1ms timer interrupt.
     unsigned int i = 0;
     for (i = 0; i < 10; i++)
     {
         P2OUT ^= FAULT_LED;
         __delay_cycles(1200000); // 50ms delay
     }

    Timer_Initialize();
    ADC_init();
    Speed_Sensor_Initialize();
    WatchDog_Init();

    __enable_interrupt(); // Enable global interrupts


     while (1)
     {
         App_Task();
         __no_operation();                       // BREAKPOINT; check ADC_Result
     }
}



// Function to set Watchdog timer interval to approximately 1s.
// MSP430FR57xx Family User's Guide > 10.3.1 WDTCTL Register
void WatchDog_Init(void)
{
    // Set watchdog timer interval to approximately 341 milleseconds
    WDTCTL = WDTPW | WDTSSEL__ACLK | WDTIS_2;    // (1/(24MHz/8192k))
}

void Board_Initialize (void)
{
    //P4DIR=0xff; P4OUT=0x00;
    //PJDIR=0xffff; PJOUT=0x0000;
    //PADIR=0xffff; PAOUT=0x0000;

    P3DIR &= HR_DRV_FAULT;          //P3.2 Input
    P2OUT |= HR_DRV_SLEEP;          // Preload HR Sleep Pin High
    P2DIR |= HR_DRV_SLEEP;          //P2.5 Output

    P3REN |= HR_DRV_FAULT;          // Enable resistor
    P3OUT |= HR_DRV_FAULT;          // Select Pull-Up

    P1DIR |= HR_FORWARD_ACT + HR_REVERSE_ACT;          // P1.2 and P1.3 as output
//P1OUT |= HR_FORWARD_ACT + HR_REVERSE_ACT;

    P3DIR &= BR_DRV_FAULT;          //P3.3 Input
    P2OUT |= BR_DRV_SLEEP;          // Preload BR Sleep Pin High
    P2DIR |= BR_DRV_SLEEP;          //P2.6 Output
    P2DIR |= FAULT_LED;             //P2.7 Output LED


    P3REN |= BR_DRV_FAULT;          // Enable resistor
    P3OUT |= BR_DRV_FAULT;          // Select Pull-Up

    P2OUT &= !FAULT_LED;             //sets LED LOW
    //P2OUT |= FAULT_LED;             //sets LED HIGH

    P1DIR |= BR_FORWARD_ACT + BR_REVERSE_ACT;          // P1.4 and P1.5 as output

//    P2DIR |= TESTING;                  //OUTPUT ACLK on P2.0
//    P2SEL1 |= TESTING;
//    P2SEL0 |= TESTING;

    P2DIR |= HALL_LOAD_SW;  //sets P2.2 as output for the load switch
    P2OUT |= HALL_LOAD_SW; //sets P2.2 high for the load switch


}

// MCU running at 24MHz

void Clock_Initialize (void)
{
    CSCTL0_H = 0xA5;
    CSCTL1 |= DCORSEL;                          // Setting DCROSEL bit to 1 to accommodate 16MHz
    CSCTL1 |= DCOFSEL_2 + DCOFSEL_1;            // Set max. DCO setting = 24MHz
//    CSCTL1 |= DCOFSEL_0;                      // Set max. DCO setting = 16MHz
    CSCTL2 = SELA_3 + SELS_3 + SELM_3;          // set ACLK = MCLK = DCO
    CSCTL3 = DIVA_0 + DIVS_0 + DIVM_0;          // Set all Dividers to none

}

void PWM_Initialize (void)
{
    P1SEL0 |= HR_FORWARD_ACT + HR_REVERSE_ACT;
    TA1CCR0 = PWM_TIMEPERIOD - 1;               // PWM Period
    TA1CCTL1 = OUTMOD_7;                        // CCR1 reset/set
    TA1CCR1 = 0;                                // CCR1 PWM duty cycle
    TA1CCTL2 = OUTMOD_7;                        // CCR1 reset/set
    TA1CCR2 = 0;                                // CCR1 PWM duty cycle
    TA1CTL = TASSEL_2 + MC_1 + TACLR;           // SMCLK, up mode, clear TAR

    P1SEL0 |= BR_FORWARD_ACT + BR_REVERSE_ACT;
    TB0CCR0 = PWM_TIMEPERIOD - 1;               // PWM Period
    TB0CCTL1 = OUTMOD_7;                        // CCR1 reset/set
    TB0CCR1 = 0;                                // CCR1 PWM duty cycle
    TB0CCTL2 = OUTMOD_7;                        // CCR2 reset/set
    TB0CCR2 = 0;                                // CCR2 PWM duty cycle
    TB0CTL = TBSSEL_2 + MC_1 + TBCLR;           // SMCLK, up mode, clear TAR
}

void Speed_Sensor_Initialize (void)
{
    P3DIR &= ~HR_HALL_SENSOR_1;         //Input of speed sensor

    if (P3IN && HR_HALL_SENSOR_1)
    {
        P3IES |= HR_HALL_SENSOR_1;      //Falling edge
        P3IE |= HR_HALL_SENSOR_1;       //Enable Interrupt
    }
    else
    {
        P3IES &= ~HR_HALL_SENSOR_1;     //Rising edge
        P3IE |= HR_HALL_SENSOR_1;       //Enable Interrupt
    }

    P3DIR &= ~HR_HALL_SENSOR_2;         //Input of speed sensor

    if (P3IN && HR_HALL_SENSOR_2)
    {
        P3IES |= HR_HALL_SENSOR_2;      //Falling edge
        P3IE |= HR_HALL_SENSOR_2;       //Enable Interrupt
    }
    else
    {
        P3IES &= ~HR_HALL_SENSOR_2;     //Rising edge
        P3IE |= HR_HALL_SENSOR_2;       //Enable Interrupt
    }

    P3DIR &= ~BR_HALL_SENSOR_1;         //Input of speed sensor

    if (P3IN && BR_HALL_SENSOR_1)
    {
        P3IES |= BR_HALL_SENSOR_1;      //Falling edge
        P3IE |= BR_HALL_SENSOR_1;       //Enable Interrupt
    }
    else
    {
        P3IES &= ~BR_HALL_SENSOR_1;     //Rising edge
        P3IE |= BR_HALL_SENSOR_1;       //Enable Interrupt
    }

    P3DIR &= ~BR_HALL_SENSOR_2;         //Input of speed sensor

    if (P3IN && BR_HALL_SENSOR_2)
    {
        P3IES |= BR_HALL_SENSOR_2;      //Falling edge
        P3IE |= BR_HALL_SENSOR_2;       //Enable Interrupt
    }
    else
    {
        P3IES &= ~BR_HALL_SENSOR_2;     //Rising edge
        P3IE |= BR_HALL_SENSOR_2;       //Enable Interrupt
    }

}
