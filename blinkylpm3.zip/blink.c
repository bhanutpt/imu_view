
/**
 * @file    blink.c
 *
 * After power-up, blink the fault LED ten times, enter LPM3, and wait for a
 * switch press (detected through ADC sampling) before repeating the blink
 * sequence.
 */

#include "msp430fr5735.h"
#include "main.h"
#include "ADC.h"
#include <stdint.h>

#define LED_TOGGLE_DELAY_CYCLES  50000u
#define LED_BLINKS_PER_SEQUENCE      10u

static void init_system(void);
static void configure_gpio(void);
static void configure_watchdog(void);
static void blink_fault_led(uint8_t count);
static void enter_low_power_until_press(void);

static volatile uint8_t g_button_event = 0;

void main(void)
{
  init_system();

  for (;;) {
    blink_fault_led(LED_BLINKS_PER_SEQUENCE);
    enter_low_power_until_press();
  }
}

static void init_system(void)
{
  WDTCTL = WDTPW | WDTHOLD;   /* Stop watchdog during setup */
  PM5CTL0 &= ~LOCKLPM5;       /* Unlock GPIOs */

  configure_gpio();
  //__bis_SR_register(LPM3_bits | GIE);

  ADC_init();
  configure_watchdog();

  __enable_interrupt();
}

static void configure_gpio(void)
{
  /* Fault LED */
  P2DIR |= FAULT_LED;
  P2OUT &= ~FAULT_LED;
}

static void configure_watchdog(void)
{
  /* Interval timer mode @ ~250 ms using ACLK (32.768 kHz REFO) */
  WDTCTL = WDTPW | WDTTMSEL | WDTSSEL__ACLK | WDTIS__8192;
  SFRIE1 |= WDTIE;
}

static void blink_fault_led(uint8_t count)
{
  while (count--) {
    P2OUT |= FAULT_LED;
    __delay_cycles(LED_TOGGLE_DELAY_CYCLES);
    P2OUT &= ~FAULT_LED;
    __delay_cycles(LED_TOGGLE_DELAY_CYCLES);
  }

  P2OUT &= ~FAULT_LED;
}

static void enter_low_power_until_press(void)
{
  do {
    g_button_event = 0;
    __bis_SR_register(LPM3_bits | GIE);
  } while (!g_button_event);
}

#pragma vector=WDT_VECTOR
__interrupt void WDT_ISR(void)
{
  if (ADC_scan_for_press()) {
    g_button_event = 1;
    __bic_SR_register_on_exit(LPM3_bits);
  }
}
