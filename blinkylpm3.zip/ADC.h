
#ifndef ADC_H_
#define ADC_H_

#include <stdint.h>

void ADC_init(void);
uint8_t ADC_scan_for_press(void);

#endif /* ADC_H_ */
