/**
 * @file    ADC.c
 *
 * Simple helper for sampling the four analog switch inputs used to wake the
 * firmware from low-power mode. Conversions are kicked on demand (from the WDT
 * ISR) and the results are evaluated against a midpoint window that represents
 * a "pressed" switch.
 */

#include <msp430.h>
#include "ADC.h"
#include "main.h"

#define SWITCH_COUNT              4u
#define SWITCH_WINDOW_MID       (512u)
#define SWITCH_WINDOW_TOLERANCE (120u)
#define SWITCH_WINDOW_MIN       (SWITCH_WINDOW_MID - SWITCH_WINDOW_TOLERANCE)
#define SWITCH_WINDOW_MAX       (SWITCH_WINDOW_MID + SWITCH_WINDOW_TOLERANCE)

static const unsigned int switch_channels[SWITCH_COUNT] = {
  ADC10INCH_6,   /* BR_FORWARD_SW  */
  ADC10INCH_7,   /* BR_REVERSE_SW  */
  ADC10INCH_12,  /* HR_REVERSE_SW  */
  ADC10INCH_13   /* HR_FORWARD_SW  */
};

static unsigned int switch_samples[SWITCH_COUNT];

static unsigned int sample_channel(unsigned int channel);
static uint8_t sample_in_window(unsigned int value);

void ADC_init(void)
{
  /* Preserve the existing analog pin mapping exactly as provided. */
  P1SEL1 |= BR_CURRENT;               /* P1.0, A0 */
  P1SEL0 |= BR_CURRENT;

  P1SEL1 |= HR_CURRENT;               /* P1.1, A1 */
  P1SEL0 |= HR_CURRENT;

  P2SEL1 |= BR_FORWARD_SW;            /* P2.3, A6 */
  P2SEL0 |= BR_FORWARD_SW;

  P2SEL1 |= BR_REVERSE_SW;            /* P2.4, A7 */
  P2SEL0 |= BR_REVERSE_SW;

  P3SEL1 |= HR_REVERSE_SW;            /* P3.0, A12 */
  P3SEL0 |= HR_REVERSE_SW;

  P3SEL1 |= HR_FORWARD_SW;            /* P3.1, A13 */
  P3SEL0 |= HR_FORWARD_SW;

  /* Basic ADC10 configuration for single channel, software-triggered samples. */
  ADC10CTL0 = ADC10SHT_4 | ADC10ON;   /* 64 ADCCLK sample, ADC on           */
  ADC10CTL1 = ADC10SHP;               /* Use sampling timer, software trig  */
  ADC10CTL2 = ADC10RES;               /* 10-bit conversions                 */
  ADC10MCTL0 = ADC10SREF_0;           /* Vref = AVCC/AVSS                   */

  __delay_cycles(1000);               /* Allow reference to settle          */
}

uint8_t ADC_scan_for_press(void)
{
  uint8_t pressed = 0;
  unsigned int idx;

  for (idx = 0; idx < SWITCH_COUNT; idx++) {
    switch_samples[idx] = sample_channel(switch_channels[idx]);
    if (sample_in_window(switch_samples[idx])) {
      pressed = 1;
    }
  }

  return pressed;
}

static unsigned int sample_channel(unsigned int channel)
{
  ADC10CTL0 &= ~ADC10ENC;
  ADC10MCTL0 = (channel | ADC10SREF_0);
  ADC10CTL0 |= ADC10ENC | ADC10SC;
  while (ADC10CTL1 & ADC10BUSY);
  return ADC10MEM0;
}

static uint8_t sample_in_window(unsigned int value)
{
  return (value >= SWITCH_WINDOW_MIN) && (value <= SWITCH_WINDOW_MAX);
}
