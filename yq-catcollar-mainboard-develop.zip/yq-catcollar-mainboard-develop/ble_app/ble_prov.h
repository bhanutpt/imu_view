#ifndef __BLE_PROV_H__
#define __BLE_PROV_H__

// #include <stdint.h>
// // #include <stdbool.h>

// // local device name
// // #define RSI_BLE_APP_DEVICE_NAME "BLE_CONFIGURATOR"
// #define RSI_BLE_APP_DEVICE_NAME "BLE_OTA_FWUP"

// extern uint8_t mobile_to_device_handle;
// extern uint16_t device_to_mobile_handle;
// extern uint16_t notify_val_handle;

// extern uint32_t rsi_ble_add_prov_serv(void);

#endif // __BLE_PROV_H__