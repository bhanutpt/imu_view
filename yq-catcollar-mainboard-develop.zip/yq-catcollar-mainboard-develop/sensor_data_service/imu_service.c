
#include "imu_service.h"
#include "lsm6dsv.h"
// #include "sl_sleeptimer.h"
#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os2.h" // FreeRTOS V2 API

#include "common.h"
#include <inttypes.h> // For PRId64
#include <stdbool.h>

static imu_output_cb_t callback; // callback for sampled data
static int trig_cnt;

// static imu_operation_mode_t imu_operation_mode = IMU_INTERRUPT_MODE;
static int imu_sampling(void);

TaskHandle_t imu_task_handle = NULL;
volatile bool imu_task_running = false;
uint32_t imu_sample_period_ms = 0;
static uint32_t imu_sample_period_remainder = 0;
static uint32_t imu_delay_remainder_acc = 0;
static uint32_t imu_timestamp_remainder_acc = 0;
static uint64_t imu_timestamp_ms = 0;
static bool imu_timestamp_seeded = false;
static output_data_rate_t imu_active_rate = IMU_ODR_0_HZ;
static uint32_t imu_debug_log_count = 0;

static int imu_sampling(void)
{
	imu_sample_t sample = {0};

	int16_t accelerometer[3]; // 单位：mg
  	int32_t gyroscope[3];     // 单位：mdps
	if (!imu_timestamp_seeded) {
		imu_timestamp_ms = get_unix_timestamp();
		imu_timestamp_remainder_acc = 0;
		imu_timestamp_seeded = true;
	} else {
		imu_timestamp_ms += imu_sample_period_ms;
		if (imu_active_rate > 0) {
			imu_timestamp_remainder_acc += imu_sample_period_remainder;
			while (imu_timestamp_remainder_acc >= (uint32_t)imu_active_rate) {
				imu_timestamp_ms += 1;
				imu_timestamp_remainder_acc -= (uint32_t)imu_active_rate;
			}
		}
	}

	sample.timestamp =  imu_timestamp_ms;
	sample.sample_count = trig_cnt;

    lsm6dsv_readdata(accelerometer, gyroscope);
    sample.ax = accelerometer[0];
    sample.ay = accelerometer[1];
    sample.az = accelerometer[2];
    sample.gx = gyroscope[0];
    sample.gy = gyroscope[1];
    sample.gz = gyroscope[2];

	if (imu_debug_log_count < 20U) {
		app_log_debug("imu_sampling[%lu] ts=%" PRIu64 " ax=%d ay=%d az=%d gx=%d gy=%d gz=%d\r\n",
		              (unsigned long)imu_debug_log_count,
		              (uint64_t)sample.timestamp,
		              (int)sample.ax,
		              (int)sample.ay,
		              (int)sample.az,
		              (int)sample.gx,
		              (int)sample.gy,
		              (int)sample.gz);
		imu_debug_log_count++;
	}

	if (callback != NULL) {
		callback(sample);
	}

	trig_cnt++;
	// app_log_debug("sample count: %d\r\n", trig_cnt);
	// uint32_t timestamp_high = (uint32_t)(sample.timestamp >> 32);
	// uint32_t timestamp_low = (uint32_t)(sample.timestamp & 0xFFFFFFFF);
	// app_log_debug("timestamp high: %u, low: %u\r\n", timestamp_high, timestamp_low);
	// app_log_debug("timestamp: %llu\r\n", sample.timestamp);
	// app_log_debug("timestamp: %u%012u\r\n", 
    //           (uint32_t)(sample.timestamp / 1000000000),
    //           (uint32_t)(sample.timestamp % 1000000000));
	// printf ("value = %" PRId64 "\n", sample.timestamp);//"I64d"
	// app_log_debug("timestamp: %ld\r\n", sample.timestamp);
	// app_log_debug("ax: %d, ay: %d, az: %d, gx: %d, gy: %d, gz: %d\r\n", sample.ax, sample.ay, sample.az, sample.gx, sample.gy, sample.gz);
	return 0;
}

static void imu_sampling_task(void *argument)
{
	UNUSED_PARAMETER(argument);
    TickType_t xLastWakeTime = xTaskGetTickCount();
    
    while (imu_task_running) {
        imu_sampling();

        uint32_t delay_ms = imu_sample_period_ms;
        if (imu_active_rate > 0) {
        	imu_delay_remainder_acc += imu_sample_period_remainder;
        	while (imu_delay_remainder_acc >= (uint32_t)imu_active_rate) {
        		delay_ms += 1;
        		imu_delay_remainder_acc -= (uint32_t)imu_active_rate;
        	}
        }
        if (delay_ms == 0) {
        	delay_ms = 1;
        }

        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(delay_ms));
    }
    
    // 任务退出前清理
	app_log_debug("delete IMU sampling task!\r\n");
    trig_cnt = 0;
    callback = NULL;
    imu_task_handle = NULL;
    vTaskDelete(NULL);
}


int imu_enable(output_data_rate_t rate, imu_output_cb_t cb)
{

	if (rate == IMU_ODR_0_HZ) {
		if (imu_task_handle != NULL){
			imu_task_running = false;
			imu_active_rate = IMU_ODR_0_HZ;

			// 等待任务安全退出（最多等待2个采样周期）
			uint32_t wait_time = imu_sample_period_ms * 2;
			if (wait_time < 10) wait_time = 10;
			
			vTaskDelay(pdMS_TO_TICKS(wait_time));
			
			// 如果任务还未退出，强制删除
			if (imu_task_handle != NULL) {
				app_log_debug("Force delete IMU sampling task!\r\n");
				vTaskDelete(imu_task_handle);
				imu_task_handle = NULL;
			}
		}
		callback = NULL;
	}else {
		// 如果任务已在运行，先停止
		if (imu_task_handle != NULL) {
			imu_task_running = false;
			vTaskDelay(pdMS_TO_TICKS(10));
		}
		
		callback = cb;
		imu_sample_period_ms = 1000 / rate;
		imu_sample_period_remainder = 1000 % rate;
		imu_delay_remainder_acc = 0;
		imu_timestamp_remainder_acc = 0;
		imu_timestamp_seeded = false;
		imu_active_rate = rate;
		trig_cnt = 0; // clear count when enabling with a non-zero rate
		imu_debug_log_count = 0;
	
		imu_task_running = true;
		BaseType_t status = xTaskCreate(
			imu_sampling_task,
			"IMUSampling",
			configMINIMAL_STACK_SIZE + 256,  // 适当增加栈大小
			NULL,
			osPriorityNormal2,            // 中等优先级
			&imu_task_handle
		);
		
		if (status != pdPASS) {
			app_log_error("Failed to create IMU sampling task!");
			imu_task_running = false;
			return -1;
		}
	}
    
    return 0;
}

int imu_get_trigger_count(void)
{
	return trig_cnt;
}
