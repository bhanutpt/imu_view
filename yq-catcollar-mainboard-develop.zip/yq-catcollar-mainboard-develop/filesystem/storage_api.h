#ifndef __STORAGE_API_H__
#define __STORAGE_API_H__

#include <stdint.h>
#include "filesystem_port.h"

// 文件系统挂载点配置
#define MOUNT_POINT_CAT   "/cat"
#define PATH_CAT(...)     MOUNT_POINT_CAT"/"__VA_ARGS__

#define MAX_PATH_LEN (256)
#define MAX_OPEN_FILES (1)

#define RAW_FRAMES_PER_RECORD     (10)
#define BLIP_SAMPLE_INTERVAL      (50)
#define RAW_IMU_RECORD_VERSION    (2U)

#define RAW_RECORD_AUX_FLAG_PRESSURE     (1U << 0)
#define RAW_RECORD_AUX_FLAG_PRESS_TEMP   (1U << 1)
#define RAW_RECORD_AUX_FLAG_MAGNETOMETER (1U << 2)
#define RAW_RECORD_AUX_FLAG_IR_OBJECT    (1U << 3)
#define RAW_RECORD_AUX_FLAG_IR_AMBIENT   (1U << 4)

extern fs_mount_t fs_mount_cat;

// opaque type for handle, internal structure is hidden
// typedef struct file_data_t file_data_t;
typedef struct file_data_t *file_handle_t;

typedef struct __attribute__((__packed__)) {
	int16_t ax, ay, az; // accelerometer   2*3 = 6 bytes
	int32_t gx, gy, gz; // gyro			   4*3 = 12 bytes
} raw_imu_data_frame_t;

// ChekrAppLink API sends raw data as a 252-byte record,
// containing 10 samples per record
typedef struct __attribute__((__packed__)) {
	uint32_t version;                 // record layout identifier
	uint32_t record_num;              // monotonically increasing record id
	uint64_t base_timestamp_ms;       // unix time in milliseconds for sample[0]
	raw_imu_data_frame_t raw_data[RAW_FRAMES_PER_RECORD];
	uint64_t aux_timestamp_ms;        // timestamp for auxiliary snapshot
	int32_t pressure_pa_x10;          // spa06 pressure in 0.1 Pa units
	int16_t pressure_temp_cC;         // spa06 temperature in 0.01 °C
	int16_t ir_object_temp_cC;        // MLX90632 object temperature in 0.01 °C
	int16_t ir_ambient_temp_cC;       // MLX90632 ambient temperature in 0.01 °C
	int16_t mag_uT_x;                 // BMM350 X in 0.01 µT
	int16_t mag_uT_y;                 // BMM350 Y in 0.01 µT
	int16_t mag_uT_z;                 // BMM350 Z in 0.01 µT
	uint16_t aux_flags;               // RAW_RECORD_AUX_FLAG_* bits
	uint16_t reserved;                // future use / alignment
} raw_imu_record_t;

// typedef struct __attribute__((__packed__)) {
// 	uint8_t start_byte;
// 	uint8_t pred_class;
// 	float pred_probability;
// 	float pred_reps;
// 	uint32_t start_timestamp;
// 	uint32_t end_timestamp;
// 	float accel_mag_mean_val;
// 	float gyro_mag_mean_val;
// 	float accel_mag_sd_val;
// 	float gyro_mag_sd_val;
// } activity_data_frame_t;
typedef struct __attribute__((__packed__)) {
	uint64_t timestamp; // currentmillis
	raw_imu_data_frame_t raw_data[RAW_FRAMES_PER_RECORD];		// 10*18 = 180 bytes
} activity_data_frame_t;

typedef struct __attribute__((__packed__)) {
	uint32_t record_num;
	activity_data_frame_t activity_data; // only one per frame
} activity_record_t;

int storage_init();
int delete_all_files();

// open a new file for writing.  returns file handle or NULL
file_handle_t storage_open_file(char *fname);
// close and save file
int storage_close_file(file_handle_t handle);

// raw IMU related interfaces
int storage_write_raw_imu_record(file_handle_t handle, raw_imu_record_t raw_record);
int storage_get_raw_imu_record_count(char *basename);

int storage_read_activity_record(char *basename, int record_number, activity_record_t *record);
int storage_get_activity_record_count(char *basename);
int storage_read_raw_imu_record(char *basename, int record_number, raw_imu_record_t *record);
// CHEKR_CONT_REC
int storage_delete_cont_rec_chunk_file(char *basename);

int storage_save_wifi_credentials(const char *ssid, const char *password);
int storage_get_wifi_credentials(char *ssid_buf, char *password_buf);

#endif // __STORAGE_APP_H__
