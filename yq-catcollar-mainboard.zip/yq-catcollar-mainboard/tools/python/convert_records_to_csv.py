
"""Convert base64-encoded IMU records into a CSV file."""

import argparse
import base64
import csv
from pathlib import Path
from typing import Iterable, Tuple

SOH = 0x02
RECORD_FRAME_LENGTH = 195
RECORD_DATA_LENGTH = 192
CRC_LENGTH = 2
RAW_FRAMES_PER_RECORD = 10


def crc16_modbus(data: bytes) -> int:
    """Return Modbus CRC-16 for the provided payload."""
    crc = 0xFFFF
    for value in data:
        crc ^= value
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ 0xA001
            else:
                crc >>= 1
    return crc & 0xFFFF


def parse_record(record_bytes: bytes) -> Tuple[int, int, Tuple[Tuple[int, ...], ...]]:
    """Parse a single 195-byte frame and return record data."""
    if len(record_bytes) != RECORD_FRAME_LENGTH:
        raise ValueError(f"Expected {RECORD_FRAME_LENGTH} bytes, got {len(record_bytes)}")

    if record_bytes[0] != SOH:
        raise ValueError(f"Unexpected start byte: 0x{record_bytes[0]:02X}")

    payload = record_bytes[1 : 1 + RECORD_DATA_LENGTH]
    received_crc = int.from_bytes(record_bytes[-CRC_LENGTH:], byteorder="big")
    calculated_crc = crc16_modbus(record_bytes[:-CRC_LENGTH])
    if received_crc != calculated_crc:
        raise ValueError(
            f"CRC mismatch: received 0x{received_crc:04X}, expected 0x{calculated_crc:04X}"
        )

    record_num = int.from_bytes(payload[0:4], byteorder="little", signed=False)
    timestamp = int.from_bytes(payload[4:12], byteorder="little", signed=False)

    samples_bytes = payload[12:]
    frames = []
    offset = 0
    for _ in range(RAW_FRAMES_PER_RECORD):
        ax = int.from_bytes(samples_bytes[offset : offset + 2], byteorder="little", signed=True)
        ay = int.from_bytes(samples_bytes[offset + 2 : offset + 4], byteorder="little", signed=True)
        az = int.from_bytes(samples_bytes[offset + 4 : offset + 6], byteorder="little", signed=True)
        gx = int.from_bytes(samples_bytes[offset + 6 : offset + 10], byteorder="little", signed=True)
        gy = int.from_bytes(samples_bytes[offset + 10 : offset + 14], byteorder="little", signed=True)
        gz = int.from_bytes(samples_bytes[offset + 14 : offset + 18], byteorder="little", signed=True)
        frames.append((ax, ay, az, gx, gy, gz))
        offset += 18

    return record_num, timestamp, tuple(frames)


def iter_records(path: Path) -> Iterable[Tuple[int, int, Tuple[Tuple[int, ...], ...]]]:
    with path.open("r", encoding="utf-8") as infile:
        for line_number, line in enumerate(infile, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            try:
                frame = base64.b64decode(stripped)
            except base64.binascii.Error as exc:  # noqa: B904
                raise ValueError(f"Line {line_number}: invalid base64 data") from exc
            try:
                yield parse_record(frame)
            except ValueError as exc:
                raise ValueError(f"Line {line_number}: {exc}") from exc


def convert_to_csv(input_path: Path, output_path: Path) -> None:
    with output_path.open("w", encoding="utf-8", newline="") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(["record_number", "timestamp", "ax", "ay", "az", "gx", "gy", "gz"])
        for record_number, timestamp, frames in iter_records(input_path):
            for ax, ay, az, gx, gy, gz in frames:
                writer.writerow([record_number, timestamp, ax, ay, az, gx, gy, gz])


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Convert base64 IMU record dump into CSV rows."
    )
    parser.add_argument("input", type=Path, help="Path to the base64 .bin file produced by start_stop_rec_ses.py")
    parser.add_argument(
        "--output",
        type=Path,
        help="Destination CSV path (defaults to <input>.csv)",
    )
    args = parser.parse_args()

    output_path = args.output or args.input.with_suffix(".csv")
    convert_to_csv(args.input, output_path)
    print(f"Wrote {output_path}")


if __name__ == "__main__":
    main()
