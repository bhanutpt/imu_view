"""Utility to request the Cat Collar MAC address over BLE and update the position."""

import argparse
import asyncio
from typing import Sequence

try:
    from bleak import BleakClient
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "bleak is required. Install with `pip install bleak`."
    ) from exc

GET_MAC_COMMAND = bytes([0x01, 0x07, 0xF1, 0x01, 0x00, 0xD7, 0x48])
SET_POSITION_COMMAND = bytes([0x01, 0x07, 0xF1, 0x04, 0x06, 0x85, 0xCB])
WRITE_CHAR_UUID = "6765A69D-CD79-4DF6-AAD5-043DF9425556"  # ble_app/ble_profile.c:cat_tx_char_serv
READ_CHAR_UUID = "B6AB2CE3-A5AA-436A-817A-CC13A45AAB76"  # ble_app/ble_profile.c:cat_rx_char_serv
ACK_SUCCESS = 0x11


def crc16_modbus(payload: Sequence[int]) -> int:
    """Return Modbus CRC-16 for the provided payload."""
    crc = 0xFFFF
    for value in payload:
        crc ^= value
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ 0xA001
            else:
                crc >>= 1
    return crc & 0xFFFF


def parse_frame(frame: bytes, expected_command: int) -> bytes:
    """Validate the response frame and return the payload for the expected command."""
    if len(frame) < 7:
        raise ValueError(f"Response too short: {frame!r}")

    expected_len = frame[1]
    if expected_len != len(frame):
        raise ValueError(
            f"Length mismatch: header says {expected_len}, got {len(frame)}"
        )

    command = frame[3]
    if command != expected_command:
        raise ValueError(f"Unexpected command in response: 0x{command:02X}")

    ack = frame[4]
    if ack != ACK_SUCCESS:
        raise ValueError(f"Device reported error ack 0x{ack:02X}")

    frame_without_crc = frame[:-2]
    received_crc = int.from_bytes(frame[-2:], byteorder="big")
    calculated_crc = crc16_modbus(frame_without_crc)
    if received_crc != calculated_crc:
        raise ValueError(
            f"CRC mismatch: received 0x{received_crc:04X}, expected 0x{calculated_crc:04X}"
        )

    return frame[5:-2]


def parse_mac_response(frame: bytes) -> str:
    """Return the MAC address string extracted from the response frame."""
    payload = parse_frame(frame, GET_MAC_COMMAND[3])
    if len(payload) < 6:
        raise ValueError(f"MAC payload too short: {payload!r}")
    mac_bytes = payload[:6]
    return ":".join(f"{byte:02X}" for byte in mac_bytes)


def parse_position_response(frame: bytes) -> bytes:
    """Return the payload from the set-position response."""
    return parse_frame(frame, SET_POSITION_COMMAND[3])


async def request_mac_and_set_position(
    address: str, write_uuid: str, read_uuid: str, delay_s: float
) -> None:
    async with BleakClient(address) as client:
        if not client.is_connected:
            raise RuntimeError("Failed to connect to BLE device.")

        await client.write_gatt_char(write_uuid, GET_MAC_COMMAND, response=True)
        await asyncio.sleep(delay_s)
        response = await client.read_gatt_char(read_uuid)
        mac = parse_mac_response(bytes(response))
        print(mac)

        await client.write_gatt_char(write_uuid, SET_POSITION_COMMAND, response=True)
        await asyncio.sleep(delay_s)
        response = await client.read_gatt_char(read_uuid)
        position_payload = parse_position_response(bytes(response))
        if position_payload:
            payload_hex = " ".join(f"{byte:02X}" for byte in position_payload)
            print(f"Position response payload: {payload_hex}")
        else:
            print("Position command acknowledged.")


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Send the get-mac command over BLE, print the MAC, then set the collar position."
        )
    )
    parser.add_argument("address", help="BLE device address, e.g. F0:12:34:56:78:9A")
    parser.add_argument(
        "--write-uuid",
        default=WRITE_CHAR_UUID,
        help="UUID of the write characteristic (default: %(default)s)",
    )
    parser.add_argument(
        "--read-uuid",
        default=READ_CHAR_UUID,
        help="UUID of the response characteristic (default: %(default)s)",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=0.2,
        help="Delay in seconds between write and read (default: %(default)s)",
    )
    args = parser.parse_args()

    asyncio.run(
        request_mac_and_set_position(
            args.address, args.write_uuid, args.read_uuid, args.delay
        )
    )


if __name__ == "__main__":
    main()
