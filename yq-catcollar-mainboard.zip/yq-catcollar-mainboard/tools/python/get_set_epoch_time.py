"""Utility to get and set the Cat Collar epoch time over BLE."""

import argparse
import asyncio
from datetime import datetime, timezone
from typing import Sequence

try:
    from bleak import BleakClient
except ImportError as exc:  # pragma: no cover
    raise SystemExit(
        "bleak is required. Install with `pip install bleak`."
    ) from exc

FRAME_START_REQUEST = 0x01
FRAME_START_RESPONSE = 0x02
FRAME_TYPE_REQUEST = 0xF1
FRAME_TYPE_RESPONSE = 0xF2

GET_COMMAND_ID = 0x05
SET_COMMAND_ID = 0x06
ACK_SUCCESS = 0x11

GET_EPOCH_COMMAND = bytes([FRAME_START_REQUEST, 0x07, FRAME_TYPE_REQUEST, GET_COMMAND_ID, 0x00, 0x17, 0x4A])
GET_RESPONSE_LENGTH = 0x0F
SET_FRAME_LENGTH = 0x0E
SET_RESPONSE_LENGTH = 0x08

WRITE_CHAR_UUID = "6765A69D-CD79-4DF6-AAD5-043DF9425556"  # ble_app/ble_profile.c:cat_tx_char_serv
READ_CHAR_UUID = "B6AB2CE3-A5AA-436A-817A-CC13A45AAB76"  # ble_app/ble_profile.c:cat_rx_char_serv


def crc16_modbus(payload: Sequence[int]) -> int:
    """Return Modbus CRC-16 for the provided payload."""
    crc = 0xFFFF
    for value in payload:
        crc ^= value
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ 0xA001
            else:
                crc >>= 1
    return crc & 0xFFFF


def _validate_common_response(frame: bytes, expected_length: int, expected_command: int) -> None:
    if len(frame) < expected_length:
        raise ValueError(f"Response too short: {frame!r}")

    if frame[0] != FRAME_START_RESPONSE:
        raise ValueError(f"Unexpected start byte: 0x{frame[0]:02X}")

    frame_len = frame[1]
    if frame_len != len(frame):
        raise ValueError(
            f"Length mismatch: header says {frame_len}, got {len(frame)}"
        )

    frame_type = frame[2]
    if frame_type != FRAME_TYPE_RESPONSE:
        raise ValueError(f"Unexpected frame type: 0x{frame_type:02X}")

    command = frame[3]
    if command != expected_command:
        raise ValueError(f"Unexpected command in response: 0x{command:02X}")

    ack = frame[4]
    if ack != ACK_SUCCESS:
        raise ValueError(f"Device reported error ack 0x{ack:02X}")

    frame_without_crc = frame[:-2]
    received_crc = int.from_bytes(frame[-2:], byteorder="big")
    calculated_crc = crc16_modbus(frame_without_crc)
    if received_crc != calculated_crc:
        raise ValueError(
            f"CRC mismatch: received 0x{received_crc:04X}, expected 0x{calculated_crc:04X}"
        )


def parse_get_epoch_response(frame: bytes) -> int:
    """Validate the get-epoch response and return the epoch in milliseconds."""
    _validate_common_response(frame, GET_RESPONSE_LENGTH, GET_COMMAND_ID)

    epoch_bytes = frame[5:13]
    if len(epoch_bytes) != 8:
        raise ValueError(f"Epoch payload has unexpected length: {epoch_bytes!r}")

    return int.from_bytes(epoch_bytes, byteorder="big")


def parse_set_epoch_response(frame: bytes) -> None:
    """Validate the set-epoch acknowledgement frame."""
    _validate_common_response(frame, SET_RESPONSE_LENGTH, SET_COMMAND_ID)


def build_set_epoch_command(epoch_ms: int) -> bytes:
    """Build the set-epoch command frame with the supplied epoch in milliseconds."""
    payload = epoch_ms.to_bytes(8, byteorder="big", signed=False)
    frame_without_crc = bytearray(
        [FRAME_START_REQUEST, SET_FRAME_LENGTH, FRAME_TYPE_REQUEST, SET_COMMAND_ID]
    )
    frame_without_crc.extend(payload)

    crc = crc16_modbus(frame_without_crc)
    frame_without_crc.extend(crc.to_bytes(2, byteorder="big"))
    return bytes(frame_without_crc)


def format_epoch(epoch_ms: int) -> str:
    try:
        dt = datetime.fromtimestamp(epoch_ms / 1000, tz=timezone.utc)
        return dt.isoformat()
    except (OverflowError, OSError, ValueError):
        return "<unrepresentable>"


async def get_epoch(
    client: BleakClient, write_uuid: str, read_uuid: str, delay_s: float
) -> int:
    await client.write_gatt_char(write_uuid, GET_EPOCH_COMMAND, response=True)
    await asyncio.sleep(delay_s)
    response = await client.read_gatt_char(read_uuid)
    epoch_ms = parse_get_epoch_response(bytes(response))
    return epoch_ms


async def set_epoch(
    client: BleakClient, write_uuid: str, read_uuid: str, delay_s: float, epoch_ms: int
) -> None:
    command = build_set_epoch_command(epoch_ms)
    await client.write_gatt_char(write_uuid, command, response=True)
    await asyncio.sleep(delay_s)
    response = await client.read_gatt_char(read_uuid)
    parse_set_epoch_response(bytes(response))


async def run_epoch_sequence(
    address: str, write_uuid: str, read_uuid: str, delay_s: float
) -> None:
    async with BleakClient(address) as client:
        if not client.is_connected:
            raise RuntimeError("Failed to connect to BLE device.")

        initial_epoch_ms = await get_epoch(client, write_uuid, read_uuid, delay_s)
        print(f"Initial epoch ms: {initial_epoch_ms}")
        print(f"Initial epoch UTC: {format_epoch(initial_epoch_ms)}")

        local_now = datetime.now().astimezone()
        new_epoch_ms = int(local_now.timestamp() * 1000)
        print(f"Setting epoch to local time ({local_now.isoformat()}), ms={new_epoch_ms}")
        await set_epoch(client, write_uuid, read_uuid, delay_s, new_epoch_ms)
        print("Set epoch acknowledged (ACK 0x11).")

        final_epoch_ms = await get_epoch(client, write_uuid, read_uuid, delay_s)
        print(f"Final epoch ms: {final_epoch_ms}")
        print(f"Final epoch UTC: {format_epoch(final_epoch_ms)}")
        print(f"Delta vs. local set value: {final_epoch_ms - new_epoch_ms} ms")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Get, set, and verify the Cat Collar epoch time over BLE."
    )
    parser.add_argument("address", help="BLE device address, e.g. F0:12:34:56:78:9A")
    parser.add_argument(
        "--write-uuid",
        default=WRITE_CHAR_UUID,
        help="UUID of the write characteristic (default: %(default)s)",
    )
    parser.add_argument(
        "--read-uuid",
        default=READ_CHAR_UUID,
        help="UUID of the response characteristic (default: %(default)s)",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=0.1,
        help="Delay in seconds between write and read (default: %(default)s)",
    )
    args = parser.parse_args()

    asyncio.run(
        run_epoch_sequence(args.address, args.write_uuid, args.read_uuid, args.delay)
    )


if __name__ == "__main__":
    main()
