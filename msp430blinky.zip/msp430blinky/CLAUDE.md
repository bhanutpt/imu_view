# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

MSP430 embedded firmware project for the MSP430FR5735 microcontroller. This is a simple LED blink demo that toggles P2.7 (FAULT_LED) using software delays and enters low power mode between blink cycles.

## Target Hardware

- **Device**: MSP430FR5735 (FRAM-based microcontroller)
- **Connection**: TIMSP430-USB debugger
- **Memory Layout**:
  - RAM: 0x1C00-0x1FFF (1KB)
  - FRAM: 0xE000-0xFF7F (approximately 8KB for code/data)
  - INFO segments: INFOA (0x1880) and INFOB (0x1800)

## Build System

This project uses **Texas Instruments Code Composer Studio (CCS)** v12.3.0 with TI-CGT-MSP430 compiler v21.6.1.LTS.

### Build Commands

**From CCS IDE:**
- Build project using CCS GUI (Project → Build Project)

**From command line:**
```bash
cd Debug
make all        # Build the project
make clean      # Clean build artifacts
```

The build system is Eclipse CDT-based with auto-generated makefiles in the `Debug/` directory.

### Build Outputs

- `Debug/msp430blinky.out` - ELF executable with debug symbols
- `Debug/msp430blinky.hex` - Intel HEX format for programming
- `Debug/msp430blinky.map` - Linker map file

## Code Architecture

### Single-File Application

The entire application is in `blink.c`:
- Disables watchdog timer (WDTCTL)
- Disables GPIO high-impedance mode (PM5CTL0)
- Configures P2.7 as output for LED
- Main loop: blinks LED 4 times with 6M cycle delays, then enters LPM0 (Low Power Mode 0)

### Memory Configuration

Linker script `lnk_msp430fr5735.cmd` defines:
- Memory regions (RAM, FRAM, peripherals, interrupt vectors)
- Section placement (code, data, stack in RAM, persistent data in FRAM)
- MPU (Memory Protection Unit) configuration when `_MPU_ENABLE` is defined
- Interrupt vector table mapping (INT00-INT54 and RESET)

### Key Hardware Definitions

- FAULT_LED = BIT7 (P2.7)
- Clock: Default DCO (Digitally Controlled Oscillator)
- Low power mode: LPM0 with GIE (General Interrupt Enable)

## Programming/Debugging

The project includes:
- CCXML target configuration: `targetConfigs/MSP430FR5735.ccxml`
- Launch configurations in `.launches/` for debugging sessions

Flash programming is done through CCS or via command-line tools using the .hex file.

## Compiler Flags (Notable)

- `-vmspx` - MSP430X extended architecture
- `-Ooff` - Optimization disabled (debug build)
- `--use_hw_mpy=F5` - Hardware multiplier type
- `--define=_MPU_ENABLE` - Memory Protection Unit enabled
- `--printf_support=minimal` - Minimal printf support
- Silicon errata workarounds: CPU21, CPU22, CPU40
